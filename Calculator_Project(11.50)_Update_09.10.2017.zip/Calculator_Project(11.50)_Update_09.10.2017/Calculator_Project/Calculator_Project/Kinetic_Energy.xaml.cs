﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Calculator_Project
{
    /// <summary>
    /// Interaction logic for Kinetic_Energy.xaml
    /// </summary>
    public partial class Kinetic_Energy : Window
    {
        public Kinetic_Energy()
        {
            InitializeComponent();
            label1.Content = "The formula for kinetic energy is 0.5 x mass x velocity\xb2";
        }
        PhysClass p1 = new PhysClass();
        private void button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                double mass = Convert.ToDouble(mass_input.Text);
                double velocity = Math.Pow(Convert.ToDouble(velocity_input.Text), 2);
                output.Text = "" + p1.KineticE(mass, velocity);
            }
            catch (FormatException)
            {

                MessageBox.Show("Please enter a numerical value");
            }

        }
    }
}
