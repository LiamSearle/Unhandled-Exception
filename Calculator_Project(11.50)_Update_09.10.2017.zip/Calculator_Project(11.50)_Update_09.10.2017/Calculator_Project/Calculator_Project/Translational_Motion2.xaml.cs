﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Calculator_Project
{
    /// <summary>
    /// Interaction logic for Translational_Motion2.xaml
    /// </summary>
    public partial class Translational_Motion2 : Window
    {
        public Translational_Motion2()
        {
            InitializeComponent();
            label.Content = "s is the distance travelled\nv\x2080 is the intial velocity\nt is the time\na is the acceleration ";
            label2.Content = "v\x2080";
            label7.Content = "m/s\xb2";
        }
        PhysClass p1 = new PhysClass();
        private void button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                double velocity = Convert.ToDouble(v0_input.Text);
                double acceleration = Convert.ToDouble(a_input.Text);
                double time = Convert.ToDouble(t_input.Text);
                s_output.Text = "" + p1.kinetic2(velocity, time, acceleration);
            }
            catch (FormatException)
            {

                MessageBox.Show("Please enter a numerical value");
            }

        }
    }
}
