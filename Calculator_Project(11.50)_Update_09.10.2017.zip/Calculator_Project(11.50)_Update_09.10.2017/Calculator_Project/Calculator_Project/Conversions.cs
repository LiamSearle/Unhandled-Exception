﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator_Project
{
    class Conversion
    {

        public double areaMethods(double input, string conversioninputcb, string conversionoutputcb)
        {

            //Acres to Hectares, Square Centimeter, Square Feet, Square Inch, Square Metre, Square Mile, Square Millimetre, Square Yard
            if (conversioninputcb == "Acres")
            {
                if (conversionoutputcb == "Hectares")
                {
                    return input * 0.404685642;
                }
                else if (conversionoutputcb == "Square Centimeter")
                {
                    return input / 0.000000024711;
                }
                else if (conversionoutputcb == "Square Feet")
                {
                    return input * 43560;
                }
                else if (conversionoutputcb == "Square Inch")
                {
                    return input * 6272640;
                }
                else if (conversionoutputcb == "Square Meter")
                {
                    return input * 4046.85642;
                }
                else if (conversionoutputcb == "Square Mile")
                {
                    return input * 0.0015625;
                }
                else if (conversionoutputcb == "Square Millimeter")
                {
                    return input * 4046856420;
                }
                else if (conversionoutputcb == "Square Yard")
                {
                    return input * 4840;
                }
            }
            //Hectares to other areas conversion
            if (conversioninputcb == "Hectares")
            {
                if (conversionoutputcb == "Acres")
                {
                    return input * 2.47105381;
                }
                else if (conversionoutputcb == "Square Centimeter")
                {
                    return input * 100000000;
                }
                else if (conversionoutputcb == "Square Feet")
                {
                    return input / 0.000009290304;
                }
                else if (conversionoutputcb == "Square Inch")
                {
                    return input / 0.000000064516;
                }
                else if (conversionoutputcb == "Square Meter")
                {
                    return input * 10000;
                }
                else if (conversionoutputcb == "Square Mile")
                {
                    return input / 258.998811;
                }
                else if (conversionoutputcb == "Square Millimeter")
                {
                    return input * 10000000000;
                }
                else if (conversionoutputcb == "Square Yard")
                {
                    return input / 0.000083612736;
                }

            }
            if (conversioninputcb == "Square Centimeter")
            {
                if (conversionoutputcb == "Acres")
                {
                    return input / 40468564.2;
                }
                else if (conversionoutputcb == "Hectares")
                {
                    return input / 100000000;
                }
                else if (conversionoutputcb == "Square Feet")
                {
                    return input / 929.0304;
                }
                else if (conversionoutputcb == "Square Inch")
                {
                    return input / 6.4516;
                }
                else if (conversionoutputcb == "Square Meter")
                {
                    return input / 10000;
                }
                else if (conversionoutputcb == "Square Mile")
                {
                    return input / 25899881100;
                }
                else if (conversionoutputcb == "Square Millimeter")
                {
                    return input * 100;
                }
                else if (conversionoutputcb == "Square Yard")
                {
                    return input / 8361.2736;
                }
            }
            if (conversioninputcb == "Square Feet")
            {
                if (conversionoutputcb == "Acres")
                {
                    return input / 43560;
                }
                else if (conversionoutputcb == "Hectares")
                {
                    return input * 0.000009290304;
                }
                else if (conversionoutputcb == "Square Centimeter")
                {
                    return input * 929.0304;
                }
                else if (conversionoutputcb == "Square Inch")
                {
                    return input * 144;
                }
                else if (conversionoutputcb == "Square Meter")
                {
                    return input * 0.09290304;
                }
                else if (conversionoutputcb == "Square Mile")
                {
                    return input / 27878400;
                }
                else if (conversionoutputcb == "Square Millimeter")
                {
                    return input * 92903.04;
                }
                else if (conversionoutputcb == "Square Yard")
                {
                    return input / 9;
                }
            }
            if (conversioninputcb == "Square Inch")
            {
                if (conversionoutputcb == "Acres")
                {
                    return input / 6272640;
                }
                else if (conversionoutputcb == "Hectares")
                {
                    return input * 0.000000064516;
                }
                else if (conversionoutputcb == "Square Centimeter")
                {
                    return input * 6.4516;
                }
                else if (conversionoutputcb == "Square Feet")
                {
                    return input / 144;
                }
                else if (conversionoutputcb == "Square Meter")
                {
                    return input * 0.00064516;
                }
                else if (conversionoutputcb == "Square Mile")
                {
                    return input / 4014489600;
                }
                else if (conversionoutputcb == "Square Millimeter")
                {
                    return input * 645.16;
                }
                else if (conversionoutputcb == "Square Yard")
                {
                    return input / 1296;
                }
            }
            if (conversioninputcb == "Square Meter")
            {
                if (conversionoutputcb == "Acres")
                {
                    return input / 4046.85642;
                }
                else if (conversionoutputcb == "Hectares")
                {
                    return input / 10000;
                }
                else if (conversionoutputcb == "Square Centimeter")
                {
                    return input * 10000;
                }
                else if (conversionoutputcb == "Square Feet")
                {
                    return input / 0.09290304;
                }
                else if (conversionoutputcb == "Square Inch")
                {
                    return input / 0.00064516;
                }
                else if (conversionoutputcb == "Square Mile")
                {
                    return input / 2589988.11;
                }
                else if (conversionoutputcb == "Square Millimeter")
                {
                    return input * 1000000;
                }
                else if (conversionoutputcb == "Square Yard")
                {
                    return input / 0.83612736;
                }
            }
            if (conversioninputcb == "Square Mile")
            {
                if (conversionoutputcb == "Acres")
                {
                    return input * 640;
                }
                else if (conversionoutputcb == "Hectares")
                {
                    return input * 258.998811;
                }
                else if (conversionoutputcb == "Square Centimeter")
                {
                    return input * 25899881100;
                }
                else if (conversionoutputcb == "Square Feet")
                {
                    return input * 27878400;
                }
                else if (conversionoutputcb == "Square Inch")
                {
                    return input * 4014489600;
                }
                else if (conversionoutputcb == "Square Meter")
                {
                    return input * 2589988.11;
                }
                else if (conversionoutputcb == "Square Millimeter")
                {
                    return input * 2589988110000;
                }
                else if (conversionoutputcb == "Square Yard")
                {
                    return input * 3097600;
                }
            }
            if (conversioninputcb == "Square Millimeter")
            {
                if (conversionoutputcb == "Acres")
                {
                    return input / 4046856420;
                }
                else if (conversionoutputcb == "Hectares")
                {
                    return input / 10000000000;
                }
                else if (conversionoutputcb == "Square Centimeter")
                {
                    return input / 100;
                }
                else if (conversionoutputcb == "Square Feet")
                {
                    return input / 92903.04;
                }
                else if (conversionoutputcb == "Square Inch")
                {
                    return input / 645.16;
                }
                else if (conversionoutputcb == "Square Meter")
                {
                    return input / 1000000;
                }
                else if (conversionoutputcb == "Square Mile")
                {
                    return input / 2589988110000;
                }
                else if (conversionoutputcb == "Square Yard")
                {
                    return input / 836127.36;
                }
            }
            if (conversioninputcb == "Square Yard")
            {
                if (conversionoutputcb == "Acres")
                {
                    return input / 4840;
                }
                else if (conversionoutputcb == "Hectares")
                {
                    return input * 0.000083612736;
                }
                else if (conversionoutputcb == "Square Centimeter")
                {
                    return input * 8361.2736;
                }
                else if (conversionoutputcb == "Square Feet")
                {
                    return input * 9;
                }
                else if (conversionoutputcb == "Square Inch")
                {
                    return input * 1296;
                }
                else if (conversionoutputcb == "Square Meter")
                {
                    return input * 0.83612736;
                }
                else if (conversionoutputcb == "Square Mile")
                {
                    return input / 3097600;
                }
                else if (conversionoutputcb == "Square Millimeter")
                {
                    return input * 836127.36;
                }
            }
            return -1;
        }

        public double angleMethods(double input, string conversioninputcb, string conversionoutputcb)
        {
            //same conversions
            if (conversioninputcb == conversionoutputcb) return input;
            //radians to degrees and degrees to radians
            if (conversioninputcb == "Degrees" && conversionoutputcb == "Radians")
            {
                return input * (Math.PI / 180);
            }
            if (conversioninputcb == "Radians" && conversionoutputcb == "Degrees")
            {
                return input * (180 / Math.PI);
            }
            //degrees to gradians and gradians to degrees
            if (conversioninputcb == "Gradians" && conversionoutputcb == "Degrees")
            {
                return input * 9 / 10;
            }

            if (conversioninputcb == "Degrees" && conversionoutputcb == "Gradians")
            {
                return input * 10 / 9;
            }

            //radians to gradians and gradians to degrees
            if (conversioninputcb == "Gradians" && conversionoutputcb == "Radians")
            {
                return input * (Math.PI / 200);
            }

            if (conversioninputcb == "Radians" && conversionoutputcb == "Gradians")
            {
                return input * (200 / Math.PI);
            }
            return -1;
        }

        public double dataStorageMethods(double input, string conversioninputcb, string conversionoutputcb)
        {
            if (conversioninputcb == conversionoutputcb)
            {
                return input;
            }
            if (conversioninputcb == "Bits")
            {
                if (conversionoutputcb == "Bytes")
                {
                    return input / 8;
                }
                else if (conversionoutputcb == "Kilobits")
                {
                    return input / 1024;
                }
                else if (conversionoutputcb == "Kilobytes")
                {
                    return input / 8192;
                }
                else if (conversionoutputcb == "Megabits")
                {
                    return input / 1048576;
                }
                else if (conversionoutputcb == "Megabytes")
                {
                    return input / 8388608;
                }
                else if (conversionoutputcb == "Gigabits")
                {
                    return input / 1073741824;
                }
                else if (conversionoutputcb == "Gigabytes")
                {
                    return input / 8589934592;
                }
                else if (conversionoutputcb == "Terabits")
                {
                    return input / 1099511627776;
                }
                else if (conversionoutputcb == "Terabytes")
                {
                    return input / 8796093022208;
                }
                else if (conversionoutputcb == "Petabits")
                {
                    return input / 1125899906842620;
                }
                else if (conversionoutputcb == "Petabytes")
                {
                    return input / 9007199254740990;
                }
            }
            if (conversioninputcb == "Bytes")
            {
                if (conversionoutputcb == "Bits")
                {
                    return input * 8;
                }
                else if (conversionoutputcb == "Kilobits")
                {
                    return input / 128;
                }
                else if (conversionoutputcb == "Kilobytes")
                {
                    return input / 1024;
                }
                else if (conversionoutputcb == "Megabits")
                {
                    return input / 131072;
                }
                else if (conversionoutputcb == "Megabytes")
                {
                    return input / 1048576;
                }
                else if (conversionoutputcb == "Gigabits")
                {
                    return input / 134217728;
                }
                else if (conversionoutputcb == "Gigabytes")
                {
                    return input / 1073741824;
                }
                else if (conversionoutputcb == "Terabits")
                {
                    return input / 137438953472;
                }
                else if (conversionoutputcb == "Terabytes")
                {
                    return input / 1099511627776;
                }
                else if (conversionoutputcb == "Petabits")
                {
                    return input / 140737488355328;
                }
                else if (conversionoutputcb == "Petabytes")
                {
                    return input / 1125899906842620;
                }
            }
            if (conversioninputcb == "Kilobits")
            {
                if (conversionoutputcb == "Bits")
                {
                    return input * 1024;
                }
                else if (conversionoutputcb == "Bytes")
                {
                    return input * 128;
                }
                else if (conversionoutputcb == "Kilobytes")
                {
                    return input / 8;
                }
                else if (conversionoutputcb == "Megabits")
                {
                    return input / 1024;
                }
                else if (conversionoutputcb == "Megabytes")
                {
                    return input / 8192;
                }
                else if (conversionoutputcb == "Gigabits")
                {
                    return input / 1048576;
                }
                else if (conversionoutputcb == "Gigabytes")
                {
                    return input / 8388608;
                }
                else if (conversionoutputcb == "Terabits")
                {
                    return input / 1073741824;
                }
                else if (conversionoutputcb == "Terabytes")
                {
                    return input / 8589934592;
                }
                else if (conversionoutputcb == "Petabits")
                {
                    return input / 1099511627776;
                }
                else if (conversionoutputcb == "Petabytes")
                {
                    return input / 8796093022208;
                }
            }
            if (conversioninputcb == "Kilobytes")
            {
                if (conversionoutputcb == "Bits")
                {
                    return input / 8192;
                }
                else if (conversionoutputcb == "Bytes")
                {
                    return input * 1024;
                }
                else if (conversionoutputcb == "Kilobits")
                {
                    return input * 8;
                }
                else if (conversionoutputcb == "Megabits")
                {
                    return input / 128;
                }
                else if (conversionoutputcb == "Megabytes")
                {
                    return input / 1024;
                }
                else if (conversionoutputcb == "Gigabits")
                {
                    return input / 131072;
                }
                else if (conversionoutputcb == "Gigabytes")
                {
                    return input / 1048576;
                }
                else if (conversionoutputcb == "Terabits")
                {
                    return input / 134217728;
                }
                else if (conversionoutputcb == "Terabytes")
                {
                    return input / 1073741824;
                }
                else if (conversionoutputcb == "Petabits")
                {
                    return input / 137438953472;
                }
                else if (conversionoutputcb == "Petabytes")
                {
                    return input / 1099511627776;
                }
            }
            if (conversioninputcb == "Megabits")
            {
                if (conversionoutputcb == "Bits")
                {
                    return input * 1048576;
                }
                else if (conversionoutputcb == "Bytes")
                {
                    return input * 131072;
                }
                else if (conversionoutputcb == "Kilobits")
                {
                    return input * 1024;
                }
                else if (conversionoutputcb == "Kilobytes")
                {
                    return input * 128;
                }
                else if (conversionoutputcb == "Megabytes")
                {
                    return input / 8;
                }
                else if (conversionoutputcb == "Gigabits")
                {
                    return input / 1024;
                }
                else if (conversionoutputcb == "Gigabytes")
                {
                    return input / 8192;
                }
                else if (conversionoutputcb == "Terabits")
                {
                    return input / 1048576;
                }
                else if (conversionoutputcb == "Terabytes")
                {
                    return input / 8388608;
                }
                else if (conversionoutputcb == "Petabits")
                {
                    return input / 1073741824;
                }
                else if (conversionoutputcb == "Petabytes")
                {
                    return input / 8589934592;
                }
            }
            if (conversioninputcb == "Megabytes")
            {
                if (conversionoutputcb == "Bits")
                {
                    return input * 8388608;
                }
                else if (conversionoutputcb == "Bytes")
                {
                    return input * 1048576;
                }
                else if (conversionoutputcb == "Kilobits")
                {
                    return input * 8192;
                }
                else if (conversionoutputcb == "Kilobytes")
                {
                    return input * 1024;
                }
                else if (conversionoutputcb == "Megabits")
                {
                    return input * 8;
                }
                else if (conversionoutputcb == "Gigabits")
                {
                    return input / 128;
                }
                else if (conversionoutputcb == "Gigabytes")
                {
                    return input / 1024;
                }
                else if (conversionoutputcb == "Terabits")
                {
                    return input / 131072;
                }
                else if (conversionoutputcb == "Terabytes")
                {
                    return input / 1048576;
                }
                else if (conversionoutputcb == "Petabits")
                {
                    return input / 134217728;
                }
                else if (conversionoutputcb == "Petabytes")
                {
                    return input / 1073741824;
                }
            }
            if (conversioninputcb == "Gigabits")
            {
                if (conversionoutputcb == "Bits")
                {
                    return input * 1073741824;
                }
                else if (conversionoutputcb == "Bytes")
                {
                    return input * 134217728;
                }
                else if (conversionoutputcb == "Kilobits")
                {
                    return input * 1048576;
                }
                else if (conversionoutputcb == "Kilobytes")
                {
                    return input * 131072;
                }
                else if (conversionoutputcb == "Megabits")
                {
                    return input * 1024;
                }
                else if (conversionoutputcb == "Megabytes")
                {
                    return input * 128;
                }
                else if (conversionoutputcb == "Gigabytes")
                {
                    return input / 8;
                }
                else if (conversionoutputcb == "Terabits")
                {
                    return input / 1024;
                }
                else if (conversionoutputcb == "Terabytes")
                {
                    return input / 8192;
                }
                else if (conversionoutputcb == "Petabits")
                {
                    return input / 1048576;
                }
                else if (conversionoutputcb == "Petabytes")
                {
                    return input / 8388608;
                }
            }
            if (conversioninputcb == "Gigabytes")
            {
                if (conversionoutputcb == "Bits")
                {
                    return input * 8589934592;
                }
                else if (conversionoutputcb == "Bytes")
                {
                    return input * 1073741824;
                }
                else if (conversionoutputcb == "Kilobits")
                {
                    return input * 8388608;
                }
                else if (conversionoutputcb == "Kilobytes")
                {
                    return input * 1048576;
                }
                else if (conversionoutputcb == "Megabits")
                {
                    return input * 8192;
                }
                else if (conversionoutputcb == "Megabytes")
                {
                    return input * 1024;
                }
                else if (conversionoutputcb == "Gigabits")
                {
                    return input * 8;
                }
                else if (conversionoutputcb == "Terabits")
                {
                    return input / 128;
                }
                else if (conversionoutputcb == "Terabytes")
                {
                    return input / 1024;
                }
                else if (conversionoutputcb == "Petabits")
                {
                    return input / 131072;
                }
                else if (conversionoutputcb == "Petabytes")
                {
                    return input / 1048576;
                }
            }
            if (conversioninputcb == "Terabits")
            {
                if (conversionoutputcb == "Bits")
                {
                    return input * 1099511627776;
                }
                else if (conversionoutputcb == "Bytes")
                {
                    return input * 137438953472;
                }
                else if (conversionoutputcb == "Kilobits")
                {
                    return input * 1073741824;
                }
                else if (conversionoutputcb == "Kilobytes")
                {
                    return input * 134217728;
                }
                else if (conversionoutputcb == "Megabits")
                {
                    return input * 1048576;
                }
                else if (conversionoutputcb == "Megabytes")
                {
                    return input * 131072;
                }
                else if (conversionoutputcb == "Gigabits")
                {
                    return input * 1024;
                }
                else if (conversionoutputcb == "Gigabytes")
                {
                    return input * 128;
                }
                else if (conversionoutputcb == "Terabytes")
                {
                    return input / 8;
                }
                else if (conversionoutputcb == "Petabits")
                {
                    return input / 1024;
                }
                else if (conversionoutputcb == "Petabytes")
                {
                    return input / 8192;
                }
            }
            if (conversioninputcb == "Terabytes")
            {
                if (conversionoutputcb == "Bits")
                {
                    return input * 8796093022208;
                }
                else if (conversionoutputcb == "Bytes")
                {
                    return input * 1099511627776;
                }
                else if (conversionoutputcb == "Kilobits")
                {
                    return input * 8589934592;
                }
                else if (conversionoutputcb == "Kilobytes")
                {
                    return input * 1073741824;
                }
                else if (conversionoutputcb == "Megabits")
                {
                    return input * 8388608;
                }
                else if (conversionoutputcb == "Megabytes")
                {
                    return input * 1048576;
                }
                else if (conversionoutputcb == "Gigabits")
                {
                    return input * 8192;
                }
                else if (conversionoutputcb == "Gigabytes")
                {
                    return input * 1024;
                }
                else if (conversionoutputcb == "Terabits")
                {
                    return input * 8;
                }
                else if (conversionoutputcb == "Petabits")
                {
                    return input / 128;
                }
                else if (conversionoutputcb == "Petabytes")
                {
                    return input / 1024;
                }
            }
            if (conversioninputcb == "Petabits")
            {
                if (conversionoutputcb == "Bits")
                {
                    return input * 1125899906842620;
                }
                else if (conversionoutputcb == "Bytes")
                {
                    return input * 140737488355328;
                }
                else if (conversionoutputcb == "Kilobits")
                {
                    return input * 1099511627776;
                }
                else if (conversionoutputcb == "Kilobytes")
                {
                    return input * 137438953472;
                }
                else if (conversionoutputcb == "Megabits")
                {
                    return input * 1073741824;
                }
                else if (conversionoutputcb == "Megabytes")
                {
                    return input * 134217728;
                }
                else if (conversionoutputcb == "Gigabits")
                {
                    return input * 1048576;
                }
                else if (conversionoutputcb == "Gigabytes")
                {
                    return input * 131072;
                }
                else if (conversionoutputcb == "Terabits")
                {
                    return input * 1024;
                }
                else if (conversionoutputcb == "Terabytes")
                {
                    return input * 128;
                }
                else if (conversionoutputcb == "Petabytes")
                {
                    return input / 8;
                }
            }
            if (conversioninputcb == "Petabytes")
            {
                if (conversionoutputcb == "Bits")
                {
                    return input * 9007199254740990;
                }
                else if (conversionoutputcb == "Bytes")
                {
                    return input * 1125899906842620;
                }
                else if (conversionoutputcb == "Kilobits")
                {
                    return input * 8796093022208;
                }
                else if (conversionoutputcb == "Kilobytes")
                {
                    return input * 1099511627776;
                }
                else if (conversionoutputcb == "Megabits")
                {
                    return input * 8589934592;
                }
                else if (conversionoutputcb == "Megabytes")
                {
                    return input * 1073741824;
                }
                else if (conversionoutputcb == "Gigabits")
                {
                    return input * 8388608;
                }
                else if (conversionoutputcb == "Gigabytes")
                {
                    return input * 1048576;
                }
                else if (conversionoutputcb == "Terabits")
                {
                    return input * 8192;
                }
                else if (conversionoutputcb == "Terabytes")
                {
                    return input * 1024;
                }
                else if (conversionoutputcb == "Petabits")
                {
                    return input * 8;
                }
            }
            return -1;
        }

        public double frequencyMethods(double input, string conversioninputcb, string conversionoutputcb)
        {
            if (conversioninputcb == conversionoutputcb)
            {
                return input;
            }
            if (conversioninputcb == "Microhertz")
            {
                if (conversionoutputcb == "Hertz")
                {
                    return input / 1000000;
                }
                else if (conversionoutputcb == "Kilohertz")
                {
                    return input / 1000000000;
                }
                else if (conversionoutputcb == "Megahertz")
                {
                    return input / 1000000000000;
                }
                else if (conversionoutputcb == "Gigahertz")
                {
                    return input / 1000000000000000;
                }
            }
            if (conversioninputcb == "Hertz")
            {
                if (conversionoutputcb == "Microhertz")
                {
                    return input * 1000000;
                }
                else if (conversionoutputcb == "Kilohertz")
                {
                    return input / 1000;
                }
                else if (conversionoutputcb == "Megahertz")
                {
                    return input / 1000000;
                }
                else if (conversionoutputcb == "Gigahertz")
                {
                    return input / 1000000000;
                }
            }
            if (conversioninputcb == "Kilohertz")
            {
                if (conversionoutputcb == "Microhertz")
                {
                    return input * 1000000000;
                }
                else if (conversionoutputcb == "Hertz")
                {
                    return input * 1000;
                }
                else if (conversionoutputcb == "Megahertz")
                {
                    return input / 1000;
                }
                else if (conversionoutputcb == "Gigahertz")
                {
                    return input / 1000000;
                }
            }
            if (conversioninputcb == "Megahertz")
            {
                if (conversionoutputcb == "Microhertz")
                {
                    return input * 1000000000000;
                }
                else if (conversionoutputcb == "Hertz")
                {
                    return input * 1000000;
                }
                else if (conversionoutputcb == "Kilohertz")
                {
                    return input * 1000;
                }
                else if (conversionoutputcb == "Gigahertz")
                {
                    return input / 1000;
                }
            }
            if (conversioninputcb == "Gigahertz")
            {
                if (conversionoutputcb == "Microhertz")
                {
                    return input * 1000000000000000;
                }
                else if (conversionoutputcb == "Hertz")
                {
                    return input * 1000000000;
                }
                else if (conversionoutputcb == "Kilohertz")
                {
                    return input * 1000000;
                }
                else if (conversionoutputcb == "Megahertz")
                {
                    return input * 1000;
                }
            }
            return -1;
        }

        public double lengthMethods(double input, string conversioninputcb, string conversionoutputcb)
        {
            if (conversioninputcb == conversionoutputcb)
            {
                return input;
            }
            if (conversioninputcb == "Nanometers")
            {
                if (conversionoutputcb == "Microns")
                {
                    return input * 0.0010;
                }
                else if (conversionoutputcb == "Millimeters")
                {
                    return input / 1000000;
                }
                else if (conversionoutputcb == "Centimeters")
                {
                    return input / 10000000;
                }
                else if (conversionoutputcb == "Meters")
                {
                    return input / 1000000000;
                }
                else if (conversionoutputcb == "Kilometers")
                {
                    return input / 1000000000000;
                }
                else if (conversionoutputcb == "Inches")
                {
                    return input / 25400000;
                }
                else if (conversionoutputcb == "Feet")
                {
                    return input / 304800000;
                }
                else if (conversionoutputcb == "Yards")
                {
                    return input / 914400000;
                }
                else if (conversionoutputcb == "Miles")
                {
                    return input / 1609344000000;
                }
                else if (conversionoutputcb == "Nautical Miles")
                {
                    return input / 1852000000000;
                }
            }
            if (conversioninputcb == "Microns")
            {
                if (conversionoutputcb == "Nanometers")
                {
                    return input * 1000;
                }
                else if (conversionoutputcb == "Millimeters")
                {
                    return input * 0.0010;
                }
                else if (conversionoutputcb == "Centimeters")
                {
                    return input * 0.00010;
                }
                else if (conversionoutputcb == "Meters")
                {
                    return input * 0.0000010;
                }
                else if (conversionoutputcb == "Kilometers")
                {
                    return input * 0.0000000010;
                }
                else if (conversionoutputcb == "Inches")
                {
                    return input * 0.000039;
                }
                else if (conversionoutputcb == "Feet")
                {
                    return input * 0.0000033;
                }
                else if (conversionoutputcb == "Yards")
                {
                    return input * 0.0000011;
                }
                else if (conversionoutputcb == "Miles")
                {
                    return input * 0.00000000062;
                }
                else if (conversionoutputcb == "Nautical Miles")
                {
                    return input * 0.00000000054;
                }
            }
            if (conversioninputcb == "Millimeters")
            {
                if (conversionoutputcb == "Nanometers")
                {
                    return input * 1000000;
                }
                else if (conversionoutputcb == "Microns")
                {
                    return input * 1000;
                }
                else if (conversionoutputcb == "Centimeters")
                {
                    return input / 10;
                }
                else if (conversionoutputcb == "Meters")
                {
                    return input / 1000;
                }
                else if (conversionoutputcb == "Kilometers")
                {
                    return input / 1000000;
                }
                else if (conversionoutputcb == "Inches")
                {
                    return input / 25.4;
                }
                else if (conversionoutputcb == "Feet")
                {
                    return input / 304.8;
                }
                else if (conversionoutputcb == "Yards")
                {
                    return input / 914.4;
                }
                else if (conversionoutputcb == "Miles")
                {
                    return input / 1609344;
                }
                else if (conversionoutputcb == "Nautical Miles")
                {
                    return input / 1852000;
                }
            }
            if (conversioninputcb == "Centimeters")
            {
                if (conversionoutputcb == "Nanometers")
                {
                    return input * 10000000;
                }
                else if (conversionoutputcb == "Microns")
                {
                    return input * 10000;
                }
                else if (conversionoutputcb == "Millimeters")
                {
                    return input * 10;
                }
                else if (conversionoutputcb == "Meters")
                {
                    return input / 100;
                }
                else if (conversionoutputcb == "Kilometers")
                {
                    return input / 100000;
                }
                else if (conversionoutputcb == "Inches")
                {
                    return input / 2.54;
                }
                else if (conversionoutputcb == "Feet")
                {
                    return input / 30.48;
                }
                else if (conversionoutputcb == "Yards")
                {
                    return input / 91.44;
                }
                else if (conversionoutputcb == "Miles")
                {
                    return input / 160934.4;
                }
                else if (conversionoutputcb == "Nautical Miles")
                {
                    return input / 185200;
                }
            }
            if (conversioninputcb == "Meters")
            {
                if (conversionoutputcb == "Nanometers")
                {
                    return input * 1000000000;
                }
                else if (conversionoutputcb == "Microns")
                {
                    return input * 1000000;
                }
                else if (conversionoutputcb == "Millimeters")
                {
                    return input * 1000;
                }
                else if (conversionoutputcb == "Centimeters")
                {
                    return input * 100;
                }
                else if (conversionoutputcb == "Kilometers")
                {
                    return input / 1000;
                }
                else if (conversionoutputcb == "Inches")
                {
                    return input / 0.0254;
                }
                else if (conversionoutputcb == "Feet")
                {
                    return input / 0.3048;
                }
                else if (conversionoutputcb == "Yards")
                {
                    return input / 0.9144;
                }
                else if (conversionoutputcb == "Miles")
                {
                    return input / 1609.344;
                }
                else if (conversionoutputcb == "Nautical Miles")
                {
                    return input / 1852;
                }
            }
            if (conversioninputcb == "Kilometers")
            {
                if (conversionoutputcb == "Nanometers")
                {
                    return input * 1000000000000;
                }
                else if (conversionoutputcb == "Microns")
                {
                    return input * 1000000000;
                }
                else if (conversionoutputcb == "Millimeters")
                {
                    return input * 1000000;
                }
                else if (conversionoutputcb == "Centimeters")
                {
                    return input * 100000;
                }
                else if (conversionoutputcb == "Meters")
                {
                    return input * 1000;
                }
                else if (conversionoutputcb == "Inches")
                {
                    return input / 0.0000254;
                }
                else if (conversionoutputcb == "Feet")
                {
                    return input / 0.0003048;
                }
                else if (conversionoutputcb == "Yards")
                {
                    return input / 0.0009144;
                }
                else if (conversionoutputcb == "Miles")
                {
                    return input / 1.609344;
                }
                else if (conversionoutputcb == "Nautical Miles")
                {
                    return input / 1.852;
                }
            }
            if (conversioninputcb == "Inches")
            {
                if (conversionoutputcb == "Nanometers")
                {
                    return input * 25400000;
                }
                else if (conversionoutputcb == "Microns")
                {
                    return input * 25400;
                }
                else if (conversionoutputcb == "Millimeters")
                {
                    return input * 25.4;
                }
                else if (conversionoutputcb == "Centimeters")
                {
                    return input * 2.54;
                }
                else if (conversionoutputcb == "Meters")
                {
                    return input * 0.0254;
                }
                else if (conversionoutputcb == "Kilometers")
                {
                    return input * 0.0000254;
                }
                else if (conversionoutputcb == "Feet")
                {
                    return input / 12;
                }
                else if (conversionoutputcb == "Yards")
                {
                    return input / 36;
                }
                else if (conversionoutputcb == "Miles")
                {
                    return input / 63360;
                }
                else if (conversionoutputcb == "Nautical Miles")
                {
                    return input / 72913.3858;
                }
            }
            if (conversioninputcb == "Feet")
            {
                if (conversionoutputcb == "Nanometers")
                {
                    return input * 304800000;
                }
                else if (conversionoutputcb == "Microns")
                {
                    return input * 304800;
                }
                else if (conversionoutputcb == "Millimeters")
                {
                    return input * 304.8;
                }
                else if (conversionoutputcb == "Centimeters")
                {
                    return input * 30.48;
                }
                else if (conversionoutputcb == "Meters")
                {
                    return input * 0.3048;
                }
                else if (conversionoutputcb == "Kilometers")
                {
                    return input * 0.0003048;
                }
                else if (conversionoutputcb == "Inches")
                {
                    return input * 12;
                }
                else if (conversionoutputcb == "Yards")
                {
                    return input / 3;
                }
                else if (conversionoutputcb == "Miles")
                {
                    return input / 5280;
                }
                else if (conversionoutputcb == "Nautical Miles")
                {
                    return input / 6076.11549;
                }
            }
            if (conversioninputcb == "Yards")
            {
                if (conversionoutputcb == "Nanometers")
                {
                    return input * 914400000;
                }
                else if (conversionoutputcb == "Microns")
                {
                    return input * 914400;
                }
                else if (conversionoutputcb == "Millimeters")
                {
                    return input * 914.4;
                }
                else if (conversionoutputcb == "Centimeters")
                {
                    return input * 91.44;
                }
                else if (conversionoutputcb == "Meters")
                {
                    return input * 0.9144;
                }
                else if (conversionoutputcb == "Kilometers")
                {
                    return input * 0.0009144;
                }
                else if (conversionoutputcb == "Inches")
                {
                    return input * 36;
                }
                else if (conversionoutputcb == "Feet")
                {
                    return input * 3;
                }
                else if (conversionoutputcb == "Miles")
                {
                    return input / 1760;
                }
                else if (conversionoutputcb == "Nautical Miles")
                {
                    return input / 2025.37183;
                }
            }
            if (conversioninputcb == "Miles")
            {
                if (conversionoutputcb == "Nanometers")
                {
                    return input * 1609344000000;
                }
                else if (conversionoutputcb == "Microns")
                {
                    return input * 1609344000;
                }
                else if (conversionoutputcb == "Millimeters")
                {
                    return input * 1609344;
                }
                else if (conversionoutputcb == "Centimeters")
                {
                    return input * 160934.4;
                }
                else if (conversionoutputcb == "Meters")
                {
                    return input * 1609.344;
                }
                else if (conversionoutputcb == "Kilometers")
                {
                    return input * 1.609344;
                }
                else if (conversionoutputcb == "Inches")
                {
                    return input * 63360;
                }
                else if (conversionoutputcb == "Feet")
                {
                    return input * 5280;
                }
                else if (conversionoutputcb == "Yards")
                {
                    return input * 1760;
                }
                else if (conversionoutputcb == "Nautical Miles")
                {
                    return input / 1.15078;
                }
            }
            if (conversioninputcb == "Nautical Miles")
            {
                if (conversionoutputcb == "Nanometers")
                {
                    return input * 1852000000000;
                }
                else if (conversionoutputcb == "Microns")
                {
                    return input * 1852000000;
                }
                else if (conversionoutputcb == "Millimeters")
                {
                    return input * 1852000;
                }
                else if (conversionoutputcb == "Centimeters")
                {
                    return input * 185200;
                }
                else if (conversionoutputcb == "Meters")
                {
                    return input * 1852;
                }
                else if (conversionoutputcb == "Kilometers")
                {
                    return input * 1.852;
                }
                else if (conversionoutputcb == "Inches")
                {
                    return input * 72913.3858;
                }
                else if (conversionoutputcb == "Feet")
                {
                    return input * 6076.11549;
                }
                else if (conversionoutputcb == "Yards")
                {
                    return input * 2025.37183;
                }
                else if (conversionoutputcb == "Miles")
                {
                    return input * 1.15078;
                }
            }
            return -1;
        }

        public double pressureMethods(double input, string conversioninputcb, string conversionoutputcb)
        {
            if (conversioninputcb == conversionoutputcb) return input;
            if (conversioninputcb == "Pascals")
            {
                if (conversionoutputcb == "Kilopascals")
                {
                    return input / 1000;
                }
                else if (conversionoutputcb == "Megapascals")
                {
                    return input / 1000000;
                }
            }
            if (conversioninputcb == "Kilopascals")
            {
                if (conversionoutputcb == "Pascals")
                {
                    return input * 1000;
                }
                else if (conversionoutputcb == "Megapascals")
                {
                    return input / 1000;
                }
            }
            if (conversioninputcb == "Megapascals")
            {
                if (conversionoutputcb == "Pascals")
                {
                    return input * 1000000;
                }
                else if (conversionoutputcb == "Kilopascals")
                {
                    return input * 1000;
                }
            }
            return -1;
        }

        public double temperatureMethods(double input, string conversioninputcb, string conversionoutputcb)
        {
            if (conversioninputcb == conversionoutputcb) return input;
            if (conversioninputcb == "Celsius")
            {
                if (conversionoutputcb == "Fahrenheit")
                {
                    return (input * 1.8) + 32;
                }
                else if (conversionoutputcb == "Kelvin")
                {
                    return input + 273.15;
                }
            }
            if (conversioninputcb == "Fahrenheit")
            {
                if (conversionoutputcb == "Celsius")
                {
                    return (((input - 32) * 5) / 9);
                }
                else if (conversionoutputcb == "Kelvin")
                {
                    return (((input - 32) * 5) / 9) + 273.15;
                }
            }
            if (conversioninputcb == "Kelvin")
            {
                if (conversionoutputcb == "Celsius")
                {
                    return input - 273.15;
                }
                else if (conversionoutputcb == "Fahrenheit")
                {
                    return ((input - 273.15) * 1.8) + 32;
                }
            }
            return -1;
        }

        public double volumeMethods(double input, string conversioninputcb, string conversionoutputcb)
        {
            if (conversioninputcb == conversionoutputcb)
            {
                return input;
            }
            if (conversioninputcb == "Milliliters")
            {
                if (conversionoutputcb == "Cubic Centimeters")
                {
                    return input / 1;
                }
                else if (conversionoutputcb == "Liters")
                {
                    return input / 1000;
                }
                else if (conversionoutputcb == "Cubic Meters")
                {
                    return input * 0.0000010;
                }
                else if (conversionoutputcb == "Cubic Inches")
                {
                    return input * 0.061;
                }
                else if (conversionoutputcb == "Cubic Feet")
                {
                    return input * 0.000035;
                }
                else if (conversionoutputcb == "Cubic Yards")
                {
                    return input * 0.0000013;
                }
            }
            if (conversioninputcb == "Cubic Centimeters")
            {
                if (conversionoutputcb == "Milliliters")
                {
                    return input * 1;
                }
                else if (conversionoutputcb == "Liters")
                {
                    return input / 1000;
                }
                else if (conversionoutputcb == "Cubic Meters")
                {
                    return input / 1000000;
                }
                else if (conversionoutputcb == "Cubic Inches")
                {
                    return input / 16.387064;
                }
                else if (conversionoutputcb == "Cubic Feet")
                {
                    return input / 28316.8466;
                }
                else if (conversionoutputcb == "Cubic Yards")
                {
                    return input / 764554.858;
                }
            }
            if (conversioninputcb == "Liters")
            {
                if (conversionoutputcb == "Milliliters" || conversionoutputcb == "Cubic Centimeters")
                {
                    return input * 1000;
                }
                else if (conversionoutputcb == "Cubic Meters")
                {
                    return input / 1000;
                }
                else if (conversionoutputcb == "Cubic Inches")
                {
                    return input * 61.02;
                }
                else if (conversionoutputcb == "Cubic Feet")
                {
                    return input * 0.035;
                }
                else if (conversionoutputcb == "Cubic Yards")
                {
                    return input * 0.0013;
                }
            }
            if (conversioninputcb == "Cubic Meters")
            {
                if (conversionoutputcb == "Milliliters" || conversionoutputcb == "Cubic Centimeters")
                {
                    return input * 1000000;
                }
                else if (conversionoutputcb == "Liters")
                {
                    return input * 1000;
                }
                else if (conversionoutputcb == "Cubic Inches")
                {
                    return input / 0.000016387064;
                }
                else if (conversionoutputcb == "Cubic Feet")
                {
                    return input / 0.0283168466;
                }
                else if (conversionoutputcb == "Cubic Yards")
                {
                    return input / 0.764554858;
                }
            }
            if (conversioninputcb == "Cubic Inches")
            {
                if (conversionoutputcb == "Milliliters" || conversionoutputcb == "Cubic Centimeters")
                {
                    return input * 16.387064;
                }
                else if (conversionoutputcb == "Liters")
                {
                    return input * 0.016;
                }
                else if (conversionoutputcb == "Cubic Meters")
                {
                    return input * 0.000016387064;
                }
                else if (conversionoutputcb == "Cubic Feet")
                {
                    return input / 1728;
                }
                else if (conversionoutputcb == "Cubic Yards")
                {
                    return input / 46656;
                }
            }
            if (conversioninputcb == "Cubic Feet")
            {
                if (conversionoutputcb == "Milliliters" || conversionoutputcb == "Cubic Centimeters")
                {
                    return input * 28316.8466;
                }
                else if (conversionoutputcb == "Liters")
                {
                    return input * 28.32;
                }
                else if (conversionoutputcb == "Cubic Meters")
                {
                    return input * 0.0283168466;
                }
                else if (conversionoutputcb == "Cubic Inches")
                {
                    return input * 1728;
                }
                else if (conversionoutputcb == "Cubic Yards")
                {
                    return input / 27;
                }
            }
            if (conversioninputcb == "Cubic Yards")
            {
                if (conversionoutputcb == "Milliliters" || conversionoutputcb == "Cubic Centimeters")
                {
                    return input * 764554.858;
                }
                else if (conversionoutputcb == "Liters")
                {
                    return input * 764.55;
                }
                else if (conversionoutputcb == "Cubic Meters")
                {
                    return input * 0.764554858;
                }
                else if (conversionoutputcb == "Cubic Inches")
                {
                    return input * 46656;
                }
                else if (conversionoutputcb == "Cubic Feet")
                {
                    return input * 27;
                }
            }
            return -1;
        }

        public double weightmassMethods(double input, string conversioninputcb, string conversionoutputcb)
        {
            if (conversioninputcb == conversionoutputcb)
            {
                return input;
            }
            if (conversioninputcb == "Milligrams")
            {
                if (conversionoutputcb == "Centigrams")
                {
                    return input / 10;
                }
                else if (conversionoutputcb == "Decigrams")
                {
                    return input / 100;
                }
                else if (conversionoutputcb == "Grams")
                {
                    return input / 1000;
                }
                else if (conversionoutputcb == "Decagrams")
                {
                    return input / 10000;
                }
                else if (conversionoutputcb == "Hectograms")
                {
                    return input / 100000;
                }
                else if (conversionoutputcb == "Kilograms")
                {
                    return input / 1000000;
                }
                else if (conversionoutputcb == "Metric Tonnes")
                {
                    return input / 1000000000;
                }
                else if (conversionoutputcb == "Ounces")
                {
                    return input / 28349.5231;
                }
                else if (conversionoutputcb == "Pounds")
                {
                    return input / 453592.37;
                }
                else if (conversionoutputcb == "Stone")
                {
                    return input / 6350293.18;
                }
            }
            if (conversioninputcb == "Centigrams")
            {
                if (conversionoutputcb == "Milligrams")
                {
                    return input * 10;
                }
                else if (conversionoutputcb == "Decigrams")
                {
                    return input / 10;
                }
                else if (conversionoutputcb == "Grams")
                {
                    return input / 100;
                }
                else if (conversionoutputcb == "Decagrams")
                {
                    return input / 1000;
                }
                else if (conversionoutputcb == "Hectograms")
                {
                    return input / 10000;
                }
                else if (conversionoutputcb == "Kilograms")
                {
                    return input / 100000;
                }
                else if (conversionoutputcb == "Metric Tonnes")
                {
                    return input / 100000000;
                }
                else if (conversionoutputcb == "Ounces")
                {
                    return input / 2834.95231;
                }
                else if (conversionoutputcb == "Pounds")
                {
                    return input / 45359.237;
                }
                else if (conversionoutputcb == "Stone")
                {
                    return input / 635029.318;
                }
            }
            if (conversioninputcb == "Decigrams")
            {
                if (conversionoutputcb == "Milligrams")
                {
                    return input * 100;
                }
                else if (conversionoutputcb == "Centigrams")
                {
                    return input * 10;
                }
                else if (conversionoutputcb == "Grams")
                {
                    return input / 10;
                }
                else if (conversionoutputcb == "Decagrams")
                {
                    return input / 100;
                }
                else if (conversionoutputcb == "Hectograms")
                {
                    return input / 1000;
                }
                else if (conversionoutputcb == "Kilograms")
                {
                    return input / 10000;
                }
                else if (conversionoutputcb == "Metric Tonnes")
                {
                    return input / 10000000;
                }
                else if (conversionoutputcb == "Ounces")
                {
                    return input / 283.495231;
                }
                else if (conversionoutputcb == "Pounds")
                {
                    return input / 4535.9237;
                }
                else if (conversionoutputcb == "Stone")
                {
                    return input / 63502.9318;
                }
            }
            if (conversioninputcb == "Grams")
            {
                if (conversionoutputcb == "Milligrams")
                {
                    return input * 1000;
                }
                else if (conversionoutputcb == "Centigrams")
                {
                    return input * 100;
                }
                else if (conversionoutputcb == "Decigrams")
                {
                    return input * 10;
                }
                else if (conversionoutputcb == "Decagrams")
                {
                    return input / 10;
                }
                else if (conversionoutputcb == "Hectograms")
                {
                    return input / 100;
                }
                else if (conversionoutputcb == "Kilograms")
                {
                    return input / 1000;
                }
                else if (conversionoutputcb == "Metric Tonnes")
                {
                    return input / 1000000;
                }
                else if (conversionoutputcb == "Ounces")
                {
                    return input / 28.3495231;
                }
                else if (conversionoutputcb == "Pounds")
                {
                    return input / 453.59237;
                }
                else if (conversionoutputcb == "Stone")
                {
                    return input / 6350.29318;
                }
            }
            if (conversioninputcb == "Decagrams")
            {
                if (conversionoutputcb == "Milligrams")
                {
                    return input * 10000;
                }
                else if (conversionoutputcb == "Centigrams")
                {
                    return input * 1000;
                }
                else if (conversionoutputcb == "Decigrams")
                {
                    return input * 100;
                }
                else if (conversionoutputcb == "Grams")
                {
                    return input * 10;
                }
                else if (conversionoutputcb == "Hectograms")
                {
                    return input / 10;
                }
                else if (conversionoutputcb == "Kilograms")
                {
                    return input / 100;
                }
                else if (conversionoutputcb == "Metric Tonnes")
                {
                    return input / 100000;
                }
                else if (conversionoutputcb == "Ounces")
                {
                    return input / 2.83495231;
                }
                else if (conversionoutputcb == "Pounds")
                {
                    return input / 45.359237;
                }
                else if (conversionoutputcb == "Stone")
                {
                    return input / 635.029318;
                }
            }
            if (conversioninputcb == "Hectograms")
            {
                if (conversionoutputcb == "Milligrams")
                {
                    return input * 100000;
                }
                else if (conversionoutputcb == "Centigrams")
                {
                    return input * 10000;
                }
                else if (conversionoutputcb == "Decigrams")
                {
                    return input * 1000;
                }
                else if (conversionoutputcb == "Grams")
                {
                    return input * 100;
                }
                else if (conversionoutputcb == "Decagrams")
                {
                    return input * 10;
                }
                else if (conversionoutputcb == "Kilograms")
                {
                    return input / 10;
                }
                else if (conversionoutputcb == "Metric Tonnes")
                {
                    return input / 10000;
                }
                else if (conversionoutputcb == "Ounces")
                {
                    return input / 0.2834952311;
                }
                else if (conversionoutputcb == "Pounds")
                {
                    return input / 4.5359237;
                }
                else if (conversionoutputcb == "Stone")
                {
                    return input / 63.5029318;
                }
            }
            if (conversioninputcb == "Kilograms")
            {
                if (conversionoutputcb == "Milligrams")
                {
                    return input * 1000000;
                }
                else if (conversionoutputcb == "Centigrams")
                {
                    return input * 100000;
                }
                else if (conversionoutputcb == "Decigrams")
                {
                    return input * 10000;
                }
                else if (conversionoutputcb == "Grams")
                {
                    return input * 1000;
                }
                else if (conversionoutputcb == "Decagrams")
                {
                    return input * 100;
                }
                else if (conversionoutputcb == "Hectograms")
                {
                    return input * 10;
                }
                else if (conversionoutputcb == "Metric Tonnes")
                {
                    return input / 1000;
                }
                else if (conversionoutputcb == "Ounces")
                {
                    return input / 0.0283495231;
                }
                else if (conversionoutputcb == "Pounds")
                {
                    return input / 0.45359237;
                }
                else if (conversionoutputcb == "Stone")
                {
                    return input / 6.35029318;
                }
            }
            if (conversioninputcb == "Metric Tonnes")
            {
                if (conversionoutputcb == "Milligrams")
                {
                    return input * 1000000000;
                }
                else if (conversionoutputcb == "Centigrams")
                {
                    return input * 100000000;
                }
                else if (conversionoutputcb == "Decigrams")
                {
                    return input * 10000000;
                }
                else if (conversionoutputcb == "Grams")
                {
                    return input * 1000000;
                }
                else if (conversionoutputcb == "Decagrams")
                {
                    return input * 100000;
                }
                else if (conversionoutputcb == "Hectograms")
                {
                    return input * 10000;
                }
                else if (conversionoutputcb == "Kilograms")
                {
                    return input * 1000;
                }
                else if (conversionoutputcb == "Ounces")
                {
                    return input / 0.0000283495231;
                }
                else if (conversionoutputcb == "Pounds")
                {
                    return input / 0.00045359237;
                }
                else if (conversionoutputcb == "Stone")
                {
                    return input / 0.00635029318;
                }
            }
            if (conversioninputcb == "Ounces")
            {
                if (conversionoutputcb == "Milligrams")
                {
                    return input * 28349.5231;
                }
                else if (conversionoutputcb == "Centigrams")
                {
                    return input * 2834.95231;
                }
                else if (conversionoutputcb == "Decigrams")
                {
                    return input * 283.495231;
                }
                else if (conversionoutputcb == "Grams")
                {
                    return input * 28.3495231;
                }
                else if (conversionoutputcb == "Decagrams")
                {
                    return input * 2.83495231;
                }
                else if (conversionoutputcb == "Hectograms")
                {
                    return input * 0.283495231;
                }
                else if (conversionoutputcb == "Kilograms")
                {
                    return input * 0.0283495231;
                }
                else if (conversionoutputcb == "Metric Tonnes")
                {
                    return input * 0.0000283495231;
                }
                else if (conversionoutputcb == "Pounds")
                {
                    return input / 16;
                }
                else if (conversionoutputcb == "Stone")
                {
                    return input / 224;
                }
            }
            if (conversioninputcb == "Pounds")
            {
                if (conversionoutputcb == "Milligrams")
                {
                    return input * 453592.37;
                }
                else if (conversionoutputcb == "Centigrams")
                {
                    return input * 45359.237;
                }
                else if (conversionoutputcb == "Decigrams")
                {
                    return input * 4535.9237;
                }
                else if (conversionoutputcb == "Grams")
                {
                    return input * 453.59237;
                }
                else if (conversionoutputcb == "Decagrams")
                {
                    return input * 45.359237;
                }
                else if (conversionoutputcb == "Hectograms")
                {
                    return input * 4.5359237;
                }
                else if (conversionoutputcb == "Kilograms")
                {
                    return input * 0.45359237;
                }
                else if (conversionoutputcb == "Metric Tonnes")
                {
                    return input * 0.00045359237;
                }
                else if (conversionoutputcb == "Ounces")
                {
                    return input * 16;
                }
                else if (conversionoutputcb == "Stone")
                {
                    return input / 14;
                }
            }
            if (conversioninputcb == "Stone")
            {
                if (conversionoutputcb == "Milligrams")
                {
                    return input * 6350293.18;
                }
                else if (conversionoutputcb == "Centigrams")
                {
                    return input * 635029.318;
                }
                else if (conversionoutputcb == "Decigrams")
                {
                    return input * 63502.9318;
                }
                else if (conversionoutputcb == "Grams")
                {
                    return input * 6350.29318;
                }
                else if (conversionoutputcb == "Decagrams")
                {
                    return input * 635.029318;
                }
                else if (conversionoutputcb == "Hectograms")
                {
                    return input * 63.5029318;
                }
                else if (conversionoutputcb == "Kilograms")
                {
                    return input * 6.35029318;
                }
                else if (conversionoutputcb == "Metric Tonnes")
                {
                    return input * 0.00635029318;
                }
                else if (conversionoutputcb == "Ounces")
                {
                    return input * 224;
                }
                else if (conversionoutputcb == "Pounds")
                {
                    return input * 14;
                }
            }
            return -1;
        }
    }

}
