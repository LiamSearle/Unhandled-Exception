﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Calculator_Project
{
    /// <summary>
    /// Interaction logic for QuadraticEquationWindow.xaml
    /// </summary>
    public partial class QuadraticEquationWindow : Window
    {
        public QuadraticEquationWindow()
        {
            InitializeComponent();
            label1.Content = "The general formula is ax\xb2+bx+c, this equation finds factors of the equation";
            label2.Content = "a";
            label3.Content = "b";
        }
        MathsClass m1 = new MathsClass();
        private void button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                double a = Convert.ToDouble(x2_box.Text);
                double b = Convert.ToDouble(x_box.Text);
                double c = Convert.ToDouble(c_box.Text);

                try
                {
                    if ((Math.Pow(b, 2) + ((-4) * a * c)) < 0)
                    {
                        throw new NaNException();
                    }
                }
                catch (NaNException)
                {
                    MessageBox.Show("There are no real roots");

                }





                a_box.Text = "" + m1.quadraticX1(a, b, c);
                b_box.Text = "" + m1.quadraticX2(a, b, c);
            }
            catch (FormatException)
            {
                MessageBox.Show("Please enter a numerical value");
            }

        }
    }
}
