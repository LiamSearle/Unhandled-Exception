﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Calculator_Project
{
    /// <summary>
    /// Interaction logic for PythagorasWindow.xaml
    /// </summary>
    public partial class PythagorasWindow : Window
    {
        public PythagorasWindow()
        {
            InitializeComponent();
            label1.Content = "The general formula for pythagoras is c=√[b\xb2+a\xb2]";
        }
        MathsClass m1 = new MathsClass();
        private void button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                c_box.Text = "" + m1.Pythagoras(Convert.ToDouble(a_box.Text), Convert.ToDouble(b_box.Text));
            }
            catch (FormatException)
            {
                MessageBox.Show("Please enter a numerical value");
            }
        }
    }
}
