﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Calculator_Project
{
    /// <summary>
    /// Interaction logic for Translational_Motion3.xaml
    /// </summary>
    public partial class Translational_Motion3 : Window
    {
        public Translational_Motion3()
        {
            InitializeComponent();
            label.Content = "v\x2081 is the final velocity\nv\x2080 is the initial velocity\na is the acceleration\ns is the distance travelled";
            label1.Content = "v\x2080";
            label6.Content = "m/s\xb2";
            label4.Content = "v\x2081";
        }
        PhysClass p1 = new PhysClass();
        private void button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                double velocity = Convert.ToDouble(v0_input.Text);
                double acceleration = Convert.ToDouble(a_input.Text);
                double distance = Convert.ToDouble(s_input.Text);
                v1_output.Text = "" + p1.kinetic3(velocity, acceleration, distance);
            }
            catch (FormatException)
            {
                MessageBox.Show("Please enter a numerical value");
            }
        }
    }
}
