﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Calculator_Project
{
    /// <summary>
    /// Interaction logic for TriangleAreaWindow.xaml
    /// </summary>
    public partial class TriangleAreaWindow : Window
    {
        public TriangleAreaWindow()
        {
            InitializeComponent();
            label7.Content = "m\xb2";
        }
        MathsClass m1 = new MathsClass();
        private void button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                output.Text = "" + m1.TriangleArea(Convert.ToDouble(base_box.Text), Convert.ToDouble(height_box.Text));
            }
            catch (FormatException)
            {
                MessageBox.Show("Please enter a numerical value");
            }

        }
    }
}
