﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace Calculator_Project
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            button4.Content = "v\x2081=v\x2080+at";
            button5.Content = "s=v\x2080t+0.5at\xb2";
            button6.Content = "v\x2081=√[v\x2080\xb2+2as]";
            try
            {

                txbMem1.Text = Loadclass.Load()[0].Split('#')[0];
                txbMem2.Text = Loadclass.Load()[0].Split('#')[1];
                txbMem3.Text = Loadclass.Load()[0].Split('#')[2];
            }
            catch (IndexOutOfRangeException)
            {

                MessageBox.Show("There is nothing to load");
            }

        }
        //START: Method of writing and saving to file
        void WriteToFile(string filename, string input)
        {
            StreamWriter w;
            if (!File.Exists(filename))
            {
                w = File.CreateText(filename);
            }
            else
            {
                w = File.AppendText(filename);
            }
            w.WriteLine(input);
            w.Close();
        }

        void LoadFromFile(string filename)
        {
            StreamReader r;
            r = File.OpenText(filename);
            string s = r.ReadLine();
            while (s != null)
            {

                s = r.ReadLine();
            }
        }

        void DeleteFile(string filename)
        {
            File.Delete(filename);
        }
        //END: Method of writing and saving to file 

        //START: Code for the Conversion ComboBox Options (24/09/17) - A
        public void addingAndRemovingCBItems(string[] array)
        {
            conversioninputcb.Items.Clear();
            conversionoutputcb.Items.Clear();
            foreach (string s in array)
            {
                conversioninputcb.Items.Add(s);
                conversionoutputcb.Items.Add(s);
            }



        }
        private void comboBoxSelection()
        {
            if (conversioncb.SelectedIndex == 0)
            {
                string[] angleoptions = { "Degrees", "Gradians", "Radians" };
                addingAndRemovingCBItems(angleoptions);
            }
            if (conversioncb.SelectedIndex == 1)
            {
                string[] areaoptions = { "Acres", "Hectares", "Square Centimeter", "Square Feet", "Square Inch", "Square Meter", "Square Mile", "Square Millimeter", "Square Yard" };
                addingAndRemovingCBItems(areaoptions);
            }
            if (conversioncb.SelectedIndex == 2)
            {
                string[] dataoptions = { "Bits", "Bytes", "Kilobits", "Kilobytes", "Megabits", "Megabytes", "Gigabits", "Gigabytes", "Terabits", "Terabytes", "Petabits", "Petabytes" };
                addingAndRemovingCBItems(dataoptions);
            }

            if (conversioncb.SelectedIndex == 3)
            {
                string[] timeoptions = { "Microhertz", "Hertz", "Kilohertz", "Megahertz", "Gigahertz" };
                addingAndRemovingCBItems(timeoptions);
            }

            if (conversioncb.SelectedIndex == 4)
            {
                string[] lengthoptions = { "Nanometers", "Microns", "Millimeters", "Centimeters", "Meters", "Kilometers", "Inches", "Feet", "Yards", "Miles", "Nautical Miles" };
                addingAndRemovingCBItems(lengthoptions);
            }

            if (conversioncb.SelectedIndex == 5)
            {
                string[] timeoptions = { "Pascals", "Kilopascals", "Megapascals" };
                addingAndRemovingCBItems(timeoptions);
            }

            if (conversioncb.SelectedIndex == 6)
            {
                string[] temperatureoptions = { "Celsius", "Fahrenheit", "Kelvin" };
                addingAndRemovingCBItems(temperatureoptions);
            }

            if (conversioncb.SelectedIndex == 7)
            {
                string[] volumeoptions = { "Milliliters", "Cubic Centimeters", "Liters", "Cubic Meters", "Cubic Inches", "Cubic Feet", "Cubic Yards" };
                addingAndRemovingCBItems(volumeoptions);
            }

            if (conversioncb.SelectedIndex == 8)
            {
                string[] weight_massoptions = { "Milligrams", "Centigrams", "Decigrams", "Grams", "Decagrams", "Hectograms", "Kilograms", "Metric Tonnes", "Ounces", "Pounds", "Stone" };
                addingAndRemovingCBItems(weight_massoptions);
            }
        }
        //END: Code for the Conversion ComboBox Options (25/09/17) - A









        //public enum frequency { Microhertz, Hertz, Kilohertz, Megahertz, Gigahertz};







        //END: Code of Methods for the Conversions ComboBox Options (25/09/17) - A
        Conversion c1 = new Conversion();
        public double callAllMethods(double input) //callsALLconversionmethods
        {
            //same conversions
            if (conversioninputcb == conversionoutputcb)
            {
                return input;
            }
            if (conversioncb.Text == "Angle") return c1.angleMethods(input, conversioninputcb.Text, conversionoutputcb.Text);
            else if (conversioncb.Text == "Area") return c1.areaMethods(input, conversioninputcb.Text, conversionoutputcb.Text);
            else if (conversioncb.Text == "Data Storage") return c1.dataStorageMethods(input, conversioninputcb.Text, conversionoutputcb.Text);
            else if (conversioncb.Text == "Frequency") return c1.frequencyMethods(input, conversioninputcb.Text, conversionoutputcb.Text);
            else if (conversioncb.Text == "Length") return c1.lengthMethods(input, conversioninputcb.Text, conversionoutputcb.Text);
            else if (conversioncb.Text == "Pressure") return c1.pressureMethods(input, conversioninputcb.Text, conversionoutputcb.Text);
            else if (conversioncb.Text == "Volume") return c1.volumeMethods(input, conversioninputcb.Text, conversionoutputcb.Text);
            else if (conversioncb.Text == "Weight/Mass") return c1.weightmassMethods(input, conversioninputcb.Text, conversionoutputcb.Text);
            else if (conversioncb.Text == "Temperature") return c1.temperatureMethods(input, conversioninputcb.Text, conversionoutputcb.Text);
            return -1;
        }
        //END: Code of Methods for the Conversions ComboBox Options - A

        private void Perimeter_ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (Perimeter_ComboBox.SelectedIndex == 0)//if the selection is square
            {

                Window1 squarePerimeterWindow = new Window1();
                squarePerimeterWindow.Show();
            }
            if (Perimeter_ComboBox.SelectedIndex == 1)//if the selection is rectangle
            {
                RectanglePerimeterWindow r1 = new RectanglePerimeterWindow();
                r1.Show();
            }
            if (Perimeter_ComboBox.SelectedIndex == 2)//if the selection is circle
            {
                CircleCircumferenceWindow c1 = new CircleCircumferenceWindow();
                c1.Show();
            }
        }


        private void Area_ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (Area_ComboBox.SelectedIndex == 0)//if the selection is an area in circle
            {
                CircleAreaWindow a1 = new CircleAreaWindow();
                a1.Show();
            }
            if (Area_ComboBox.SelectedIndex == 1)//if the selection is an area in rectangle
            {
                RectangleAreaWindow r1 = new RectangleAreaWindow();
                r1.Show();
            }
            if (Area_ComboBox.SelectedIndex == 2)
            {
                SquareAreaWindow s1 = new SquareAreaWindow();
                s1.Show();
            }
            if (Area_ComboBox.SelectedIndex == 3)
            {
                TrapeziumAreaWindow t1 = new TrapeziumAreaWindow();
                t1.Show();
            }
            if (Area_ComboBox.SelectedIndex == 4)
            {
                TriangleAreaWindow t1 = new TriangleAreaWindow();
                t1.Show();
            }
        }

        private void Volume_ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (Volume_ComboBox.SelectedIndex == 0)
            {
                CylinderVolumeWindow c1 = new CylinderVolumeWindow();
                c1.Show();
            }
            if (Volume_ComboBox.SelectedIndex == 1)
            {
                ConeVolumeWindow c1 = new ConeVolumeWindow();
                c1.Show();
            }
            if (Volume_ComboBox.SelectedIndex == 2)
            {
                SphereVolumeWindow s1 = new SphereVolumeWindow();
                s1.Show();

            }
        }



        private void Pythagoras_button_Click(object sender, RoutedEventArgs e)
        {


            PythagorasWindow p1 = new PythagorasWindow();
            p1.Show();





        }

        private void Quadratic_button_Click(object sender, RoutedEventArgs e)
        {

            QuadraticEquationWindow q1 = new QuadraticEquationWindow();
            q1.Show();




        }

        private void convertbtn_Click(object sender, RoutedEventArgs e)
        {

            double conversionresult = callAllMethods(Convert.ToDouble(conversioninputtb.Text));

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            comboBoxSelection();
        }

        private void KE_button_Click(object sender, RoutedEventArgs e)
        {
            Kinetic_Energy k1 = new Kinetic_Energy();
            k1.Show();


        }

        private void button_Click_1(object sender, RoutedEventArgs e)
        {

            Potential_Energy p1 = new Potential_Energy();
            p1.Show();


        }

        private void button1_Click_1(object sender, RoutedEventArgs e)
        {

            Gravitational_Force g1 = new Gravitational_Force();


        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {

            Centripetal_Force c1 = new Centripetal_Force();
            c1.Show();


        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {

            Heat_Energy h1 = new Heat_Energy();
            h1.Show();

        }

        private void button4_Click(object sender, RoutedEventArgs e)
        {

            Translational_Motion_1 t1 = new Translational_Motion_1();
            t1.Show();


        }



        private void button6_Click(object sender, RoutedEventArgs e)
        {

            Translational_Motion3 t3 = new Translational_Motion3();
            t3.Show();


        }

        private void button5_Click_1(object sender, RoutedEventArgs e)
        {

            Translational_Motion2 t2 = new Translational_Motion2();
            t2.Show();


        }

        private void selectionChanged(object sender, SelectionChangedEventArgs e)
        {
            comboBoxSelection();
        }

        private void conversioncb_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            comboBoxSelection();

        }

        private void button7_Click(object sender, RoutedEventArgs e)
        {

            LawOfCosines l1 = new LawOfCosines();
            l1.Show();


        }

        private void button8_Click(object sender, RoutedEventArgs e)
        {

            DistanceFormula d1 = new DistanceFormula();
            d1.Show();


        }
        Memory memClass1 = new Memory();


        private void btnMem1_Click_1(object sender, RoutedEventArgs e)
        {
            memClass1.Save(txbMem1.Text, txbMem2.Text, txbMem3.Text);
        }

        private void btnMem2_Click_1(object sender, RoutedEventArgs e)
        {
            memClass1.Save(txbMem1.Text, txbMem2.Text, txbMem3.Text);
        }

        private void btnMem3_Click_1(object sender, RoutedEventArgs e)
        {
            memClass1.Save(txbMem1.Text, txbMem2.Text, txbMem3.Text);
        }


    }
}
