﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Calculator_Project
{
    /// <summary>
    /// Interaction logic for Heat_Energy.xaml
    /// </summary>
    public partial class Heat_Energy : Window
    {
        public Heat_Energy()
        {
            InitializeComponent();
        }
        PhysClass p1 = new PhysClass();
        private void button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                double mass = Convert.ToDouble(mass_input.Text);
                double temperature = Convert.ToDouble(tempF_input.Text) - Convert.ToDouble(tempI_input.Text);
                double C1 = Convert.ToDouble(C_input.Text);

                output.Text = "" + p1.HeatEnergy(mass, temperature, C1);
            }
            catch (FormatException)
            {

                MessageBox.Show("Please enter a numerical value");
            }

        }
    }
}
