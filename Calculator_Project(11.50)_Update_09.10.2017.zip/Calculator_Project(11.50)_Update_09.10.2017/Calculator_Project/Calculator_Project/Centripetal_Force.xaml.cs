﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Calculator_Project
{
    /// <summary>
    /// Interaction logic for Centripetal_Force.xaml
    /// </summary>
    public partial class Centripetal_Force : Window
    {
        public Centripetal_Force()
        {
            InitializeComponent();
            label1.Content = $"The formula for centripetal force is (mass x velocity\xb2)/radius";
        }
        PhysClass p1 = new PhysClass();
        private void button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                double mass = Convert.ToDouble(mass_input.Text);
                double radius1 = Convert.ToDouble(radius.Text);
                double velocity1 = Math.Pow(Convert.ToDouble(velocity.Text), 2);

                output.Text = "" + p1.Centripetal(mass, radius1, velocity1);
            }
            catch (FormatException)
            {
                MessageBox.Show("Enter a numerical value please");
            }
        }
    }
}
