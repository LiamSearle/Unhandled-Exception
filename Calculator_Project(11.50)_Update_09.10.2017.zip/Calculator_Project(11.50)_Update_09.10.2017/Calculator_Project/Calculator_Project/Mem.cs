﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Calculator_Project
{


    class Memory
    {
        private string file = "..\\..\\sav.txt";
        public void Save(string mem1, string mem2, string mem3)
        {
            StreamWriter s1 = new StreamWriter(file);
            s1.Write(mem1 + "#" + mem2 + "#" + mem3);
            s1.Close();
        }

    }
    class Loadclass
    {
        private static string statfile = "..\\..\\sav.txt";
        public static string[] Load()
        {

            return File.ReadAllLines(statfile);

        }

    }
}