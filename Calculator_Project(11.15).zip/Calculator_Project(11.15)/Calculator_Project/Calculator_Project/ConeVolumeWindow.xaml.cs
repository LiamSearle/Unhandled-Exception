﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Calculator_Project
{
    /// <summary>
    /// Interaction logic for ConeVolumeWindow.xaml
    /// </summary>
    public partial class ConeVolumeWindow : Window
    {
        public ConeVolumeWindow()
        {
            InitializeComponent();
            label1.Content = ("The formula for volume of a cone is 1/3 x π x radius\xb2 x height");
            label7.Content = "m\xb3";
        }
        MathsClass m1 = new MathsClass();
        private void button_Click(object sender, RoutedEventArgs e)
        {

            output.Text = "" + m1.ConeVolume(Convert.ToDouble(radius.Text), Convert.ToDouble(height.Text));
        }
    }
}
