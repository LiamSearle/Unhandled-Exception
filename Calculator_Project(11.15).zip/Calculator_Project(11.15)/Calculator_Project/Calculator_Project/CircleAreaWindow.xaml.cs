﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Calculator_Project
{
    /// <summary>
    /// Interaction logic for CircleAreaWindow.xaml
    /// </summary>

    public partial class CircleAreaWindow : Window
    {

        public CircleAreaWindow()
        {
            InitializeComponent();
            label.Content = "The formula for area of a circle is π x radius\xb2";
            label4.Content = "m\xb2";
        }
        MathsClass m1 = new MathsClass();
        private void button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                m1.Testing(Convert.ToDouble(radius_input.Text));
                output.Text = "" + m1.CircleArea(Convert.ToDouble(radius_input.Text));
            }
            catch (Exception)
            {

                MessageBox.Show("Please enter a numerical value");
            }
            
            
            
        }
    }
}
