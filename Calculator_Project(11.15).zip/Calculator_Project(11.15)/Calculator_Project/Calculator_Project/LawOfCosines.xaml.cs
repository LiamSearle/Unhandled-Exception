﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Calculator_Project
{
    /// <summary>
    /// Interaction logic for LawOfCosines.xaml
    /// </summary>
    public partial class LawOfCosines : Window
    {
        public LawOfCosines()
        {
            InitializeComponent();
            label1.Content = "The formula for Law of Cosines is a=√[b\xb2+c\xb2-2bc(CosA)]";
        }

        MathsClass m1 = new MathsClass();
        private void button_Click(object sender, RoutedEventArgs e)
        {
            double b = Convert.ToDouble(b_input.Text);
            double c = Convert.ToDouble(c_input.Text);
            double A = Convert.ToDouble(A_input.Text);

            output.Text = "" + m1.LawOfCosines(b, c, A);
        }


    }
}
