﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Calculator_Project
{
    /// <summary>
    /// Interaction logic for DistanceFormula.xaml
    /// </summary>
    public partial class DistanceFormula : Window
    {
        public DistanceFormula()
        {
            InitializeComponent();
        }

        MathsClass m1 = new MathsClass();

        private void Calculate_Click(object sender, RoutedEventArgs e)
        {
            double x1 = Convert.ToDouble(x1_input.Text);
            double x2 = Convert.ToDouble(x2_input.Text);
            double y1 = Convert.ToDouble(y1_input.Text);
            double y2 = Convert.ToDouble(y2_input.Text);

            output.Text = "" + m1.DistanceFormula(x1, x2, y1, y2);
        }
    }
}
