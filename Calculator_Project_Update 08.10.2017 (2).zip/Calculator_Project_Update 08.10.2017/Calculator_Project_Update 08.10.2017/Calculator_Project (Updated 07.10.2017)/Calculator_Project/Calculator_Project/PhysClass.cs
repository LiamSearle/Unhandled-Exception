﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator_Project
{
    class PhysClass
    {
        public double Centripetal(double mass_input, double radius, double velocity)
        {
            double mass = Convert.ToDouble(mass_input);
            double radius1 = Convert.ToDouble(radius);
            double velocity1 = Math.Pow(Convert.ToDouble(velocity), 2);
            double calculation = (mass * velocity1) / radius1;
            calculation = Math.Round(calculation, 2);
            return calculation;
        }
        public double GravForce(double G, double mass1, double mass2, double radius)
        {

            double calculation = ((G * mass1 * mass2) / (radius));
            return calculation;
            
        }
        public double HeatEnergy(double mass, double temperature, double C1)
        {
            double calculation = mass * temperature * C1;
            return Math.Round(calculation, 2);
            
        }
        public double KineticE(double mass, double velocity)
        {
            double calculation = 0.5 * mass * velocity;
            return Math.Round(calculation, 2);
            
        }
        public double kinetic1(double velocity, double a, double t)
        {
            double calculation = velocity + (a * t);
            return Math.Round(calculation, 2);
            
        }
        public double kinetic2(double velocity, double time, double acceleration)
        {
            double calculation = ((velocity * time) + (0.5 * acceleration * Math.Pow(time, 2)));
            return Math.Round(calculation, 2);
            
        }
        public double kinetic3(double velocity, double acceleration, double distance)
        {
            double calculation = Math.Pow(velocity, 2) + (2 * acceleration * distance);
            return Math.Round(calculation, 2);
            
        }
    }
    
}
