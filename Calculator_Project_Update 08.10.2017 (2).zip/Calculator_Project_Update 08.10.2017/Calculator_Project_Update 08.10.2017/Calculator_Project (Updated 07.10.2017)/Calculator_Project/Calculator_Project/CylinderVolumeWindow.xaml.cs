﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Calculator_Project
{
    /// <summary>
    /// Interaction logic for CylinderVolumeWindow.xaml
    /// </summary>
    public partial class CylinderVolumeWindow : Window
    {
        public CylinderVolumeWindow()
        {
            InitializeComponent();
        }
        MathsClass m1 = new MathsClass();
        private void button_Click(object sender, RoutedEventArgs e)
        {

            output.Text = "" + m1.CylinderVolume(Convert.ToDouble(height.Text), Convert.ToDouble(radius.Text));

        }
    }
}
