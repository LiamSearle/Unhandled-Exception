﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator_Project
{
    class MathsClass
    {
        public double CircleArea(double radius)
        {
            
            double calculation = Math.PI * Math.Pow(Convert.ToDouble(radius), 2);
            calculation = Math.Round(calculation, 2);
            return calculation;
        }
        public double CircleCircumference(double radius_input)
        {
            double calculation = 2 * Math.PI * Convert.ToDouble(radius_input);
            calculation = Math.Round(calculation, 2);
            return (calculation);
        }
        public double ConeVolume(double radius_input, double height)
        {
            double radius1 = Convert.ToDouble(radius_input);
            double height1 = Convert.ToDouble(height);
            double calculation = (0.33333333) * (Math.Pow(radius1, 2)) * height1 * Math.PI;
            calculation = Math.Round(calculation, 2);
            return calculation;
        }
        public double CylinderVolume(double height1, double radius1)
        {

            double calculation = radius1 * radius1 * height1 * Math.PI;
            calculation = Math.Round(calculation, 2);
            return calculation;
        }
        public double Pythagoras(double a_box, double b_box)
        {
            double a = Convert.ToDouble(a_box) * Convert.ToDouble(a_box);
            double b = Convert.ToDouble(b_box) * Convert.ToDouble(b_box);
            double c2 = Math.Sqrt(a + b);
            double calculation = Math.Round(c2, 2);
            return calculation;
        }
        public double RectangleArea(double width_input, double length_input)
        {

            double calculation = Convert.ToDouble(width_input) * Convert.ToDouble(length_input);
            calculation = Math.Round(calculation, 2);
            return calculation;
        }
        public double rectanglePerimeter(double length, double width)
        {
            return Math.Round((2 * length + 2 * width), 2);
        }
        public double SphereVolume(double radius)
        {
            double radius1 = Convert.ToDouble(radius);
            double calculation = (4 / 3) * Math.PI * Math.Pow(radius1, 3);
            calculation = Math.Round(calculation, 2);
            return calculation;
        }
        public double squareArea(double side_input)
        {
            double calculation = Math.Pow(Convert.ToDouble(side_input), 2);
            calculation = Math.Round(calculation, 2);
            return calculation;
        }
        public double SquarePerimeter(double side)
        {
            double perimeter = 4 * Convert.ToDouble(side);
            return perimeter;
        }
        public double TrapArea(double parallel_line1, double parallel_line2, double height)
        {
            double sum_of_parallel_lines = Convert.ToDouble(parallel_line1) + Convert.ToDouble(parallel_line2);
            double height_calculation = Convert.ToDouble(height);
            double calculations = 0.5 * sum_of_parallel_lines * height_calculation;
            calculations = Math.Round(calculations, 2);
            return calculations;
        }
        public double TriangleArea(double base_box, double height_box)
        {
            double calculation = 0.5 * Convert.ToDouble(base_box) * Convert.ToDouble(height_box);
            calculation = Math.Round(calculation, 2);
            return calculation;
        }
        public double quadraticX1(double a, double b, double c)
        {
            double x1 = ((-b + Math.Sqrt((Math.Pow(b, 2) + ((-4) * a * c)))) / (2 * a));
            return Math.Round(x1, 2);
        }
        public double quadraticX2(double a, double b, double c)
        {
            double x2 = ((-b - Math.Sqrt((Math.Pow(b, 2) + ((-4) * a * c)))) / (2 * a));
            return Math.Round(x2, 2);
        }

        public void Testing(double a)
        {
            try
            {
                double x = a* a;
            }
            catch (FormatException)
            {

                //throw new FormatException("Please enter a numerical value.");
            }
        } 
    }
}
