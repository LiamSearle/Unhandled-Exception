﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Calculator_Project
{
    /// <summary>
    /// Interaction logic for Potential_Energy.xaml
    /// </summary>
    public partial class Potential_Energy : Window
    {
        public Potential_Energy()
        {
            InitializeComponent();
        }

        double g = 9.81;

        private void button_Click(object sender, RoutedEventArgs e)
        {
            double mass = Convert.ToDouble(mass_input.Text);
            double height = Convert.ToDouble(height_input.Text);
            double calculation = mass * g * height;
            calculation = Math.Round(calculation);
            output.Text = $"{calculation}";
        }
    }
}
