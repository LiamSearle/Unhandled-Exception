﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Calculator_Project
{
    /// <summary>
    /// Interaction logic for Gravitational_Force.xaml
    /// </summary>
    public partial class Gravitational_Force : Window
    {
        public Gravitational_Force()
        {
            InitializeComponent();
        }
        double G = 6.67 * Math.Pow(10, -11);
        PhysClass p1 = new PhysClass();
        private void button_Click(object sender, RoutedEventArgs e)
        {
            double mass1 = Convert.ToDouble(mass1_input.Text);
            double mass2 = Convert.ToDouble(mass2_input.Text);
            double radius = Math.Pow(Convert.ToDouble(radius_input.Text), 2);
            
            output.Text = "" + p1.GravForce(G, mass1, mass2, radius);
        }
    }
}
