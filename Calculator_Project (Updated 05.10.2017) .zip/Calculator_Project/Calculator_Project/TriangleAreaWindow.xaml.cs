﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Calculator_Project
{
    /// <summary>
    /// Interaction logic for TriangleAreaWindow.xaml
    /// </summary>
    public partial class TriangleAreaWindow : Window
    {
        public TriangleAreaWindow()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            double calculation = 0.5 * Convert.ToDouble(base_box.Text) * Convert.ToDouble(height_box.Text);
            calculation = Math.Round(calculation, 2);
            output.Text = $"{calculation}";
        }
    }
}
