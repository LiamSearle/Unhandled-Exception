﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Calculator_Project
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        //START: Code for the Conversion ComboBox Options (24/09/17) - A
        public void addingAndRemovingCBItems(string[] array)
        {
            conversioninputcb.Items.Clear();
            conversionoutputcb.Items.Clear();
            foreach (string s in array)
            {
                conversioninputcb.Items.Add(s);
                conversionoutputcb.Items.Add(s);
            }
        }
        private void comboBoxSelection() {
            if (conversioncb.Text == "Angle")
            {
                string[] angleoptions = { "Degrees", "Gradians", "Radians" };
                addingAndRemovingCBItems(angleoptions);
            }

            if (conversioncb.Text == "Area")
            {
                string[] areaoptions = { "Acres", "Hectares", "Square Centimetre", "Square Feet", "Square Inch", "Square Metre", "Square Mile", "Square Millimetre", "Square Yard" };
                addingAndRemovingCBItems(areaoptions);
            }
            if (conversioncb.Text == "Data Storage")
            {
                string[] dataoptions = {"Bits", "Bytes", "Kilobits", "Kibibits", "Kilobytes", "Kibibytes", "Megabits", "Mebibits", "Megabytes", "Mebibytes", "Gigabits", "Gibibits", "Gigabytes", "Gibibytes", "Terabits", "Tebibits", "Terabytes", "Tebibytes", "Petabits", "Pebibits", "Petabytes", "Pebibytes", "Exabits", "Exbibits", "Exbibits", "Exabytes", "Exbibytes", "Zetabits", "Zebibits", "Zetabytes", "Zebibytes", "Yottabit", "Yobibits", "Yottabyte", "Yobibytes"};
                addingAndRemovingCBItems(dataoptions);
            }

            if (conversioncb.Text == "Length")
            {
                string[] lengthoptions = {"Nanometres", "Microns", "Millimetres", "Centimetres", "Metres", "Kilometres", "Inches", "Feet", "Yards", "Miles", "Nautical Miles"};
                addingAndRemovingCBItems(lengthoptions);
            }

            if (conversioncb.Text == "Speed")
            {
                string[] speedoptions = { "Centimetres per second", "Metres per second", "Kilometres per hour", "Feet per second", "Miles per hour", "Knots", "Mach" };
                addingAndRemovingCBItems(speedoptions);
            }

            if (conversioncb.Text == "Temperature")
            {
                string[] temperatureoptions = { "Celsius", "Fahrenheit", "Kelvin" };
                addingAndRemovingCBItems(temperatureoptions);
            }

            if (conversioncb.Text == "Time")
            {
                string[] timeoptions = {"Nanosecond", "Microsecond", "Millisecond", "Second", "Minute", "Hour", "Day", "Week", "Month", "Year", "Decade", "Century"};
                addingAndRemovingCBItems(timeoptions);
            }

            if (conversioncb.Text == "Volume")
            {
                string[] volumeoptions = {"Millilitres", "Cubic Centimetres", "Litres", "Cubic Metres", "Cubic Inches", "Cubic Feet", "Cubic Yards" };
                addingAndRemovingCBItems(volumeoptions);
            }

            if (conversioncb.Text == "Weight/Mass")
            {
                string[] weight_massoptions = {"Carats", "Milligrams", "Centigrams", "Decigrams", "Grams", "Decagrams", "Hectograms", "Kilograms", "Metric Tonnes", "Ounces", "Pounds", "Stone"};
                addingAndRemovingCBItems(weight_massoptions);
            }
                }
        //END: Code for the Conversion ComboBox Options (25/09/17) - A

        //START: Code of Methods for the Conversions ComboBox Options (25/09/17) - A
        double angleMethods(double input)
        {
            //same conversions
            if (conversioninputcb.Text == conversionoutputcb.Text)
            {
                double result = input;
                return result;
            }
            //radians to degrees and degrees to radians
            if (conversioninputcb.Text == "Degrees" && conversionoutputcb.Text == "Radians")
            {
                double result = input * (Math.PI / 180);
                return result;
            }
            if (conversioninputcb.Text == "Radians" && conversionoutputcb.Text == "Degrees")
            {
                double result = input * (180/Math.PI);
                return result;
            }
            //degrees to gradians and gradians to degrees

            //radians to gradians and gradians to degrees
            return -1;
        }

        public double callAllMethods(double input) //callsALLconversionmethods
        {
            return angleMethods(input);
        }
        //END: Code of Methods for the Conversions ComboBox Options - A

        private void Perimeter_ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (Perimeter_ComboBox.SelectedIndex == 0)//if the selection is square
            {

                Window1 a = new Window1();//this would ideally be named something like "squarePerimeterWindow"
                a.Show();
            }
            if (Perimeter_ComboBox.SelectedIndex == 1)//if the selection is rectangle
            {
                RectanglePerimeterWindow r1 = new RectanglePerimeterWindow();
                r1.Show();
            }
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            comboBoxSelection(); //Put this code in button to test if comboBox options work - A

        }

        private void Pythagoras_button_Click(object sender, RoutedEventArgs e)
        {
         
           
        }

        private void radioButton_Checked(object sender, RoutedEventArgs e)
        {
            if (radioButton.IsChecked == true)
            {

            }
        }

        private void convertbtn_Click(object sender, RoutedEventArgs e)
        {
            double conversionresult = callAllMethods(Convert.ToDouble(conversioninputtb.Text));
            conversionoutputtb.Text = Convert.ToString(conversionresult);
        }
    }
}
