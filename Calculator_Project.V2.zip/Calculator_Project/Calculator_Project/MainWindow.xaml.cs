﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Calculator_Project
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Perimeter_ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (Perimeter_ComboBox.SelectedIndex == 0)//if the selection is square
            {

                Window1 a = new Window1();//this would ideally be named something like "squarePerimeterWindow"
                a.Show();
            }
            if (Perimeter_ComboBox.SelectedIndex == 1)//if the selection is rectangle
            {
                RectanglePerimeterWindow r1 = new RectanglePerimeterWindow();
                r1.Show();
            }
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            

        }

        private void Pythagoras_button_Click(object sender, RoutedEventArgs e)
        {
         
           
        }

        private void radioButton_Checked(object sender, RoutedEventArgs e)
        {
            if (radioButton.IsChecked == true)
            {
                
            }
        }
    }
}
