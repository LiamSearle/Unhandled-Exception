﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace Calculator_Project
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        //START: Method of writing and saving to file
        void WriteToFile(string filename, string input)
        {
            StreamWriter w;
            if (!File.Exists(filename))
            {
                w = File.CreateText(filename);
            }
            else
            {
                w = File.AppendText(filename);
            }
            w.WriteLine(input);
            w.Close();
        }

        void LoadFromFile (string filename)
        {
            StreamReader r;
            r = File.OpenText(filename);
            string s = r.ReadLine();
            while (s != null)
            {
                historydisplaytb.Text += s + "\n";
                s = r.ReadLine();
            }
        }

        void DeleteFile (string filename)
        {
            File.Delete(filename);
        }
        //END: Method of writing and saving to file 

        //START: Code for the Conversion ComboBox Options (24/09/17) - A
        public void addingAndRemovingCBItems(string[] array)
        {
            conversioninputcb.Items.Clear();
            conversionoutputcb.Items.Clear();
            foreach (string s in array)
            {
                conversioninputcb.Items.Add(s);
                conversionoutputcb.Items.Add(s);
            }
        }
        private void comboBoxSelection()
        {
            if (conversioncb.Text == "Angle")
            {
                string[] angleoptions = { "Degrees", "Gradians", "Radians" };
                addingAndRemovingCBItems(angleoptions);
            }

            if (conversioncb.Text == "Area")
            {
                string[] areaoptions = { "Acres", "Hectares", "Square Centimetre", "Square Feet", "Square Inch", "Square Metre", "Square Mile", "Square Millimetre", "Square Yard" };
                addingAndRemovingCBItems(areaoptions);
            }
            if (conversioncb.Text == "Data Storage")
            {
                string[] dataoptions = { "Bits", "Bytes", "Kilobits", "Kilobytes", "Megabits", "Megabytes", "Gigabits", "Gigabytes", "Terabits", "Terabytes", "Petabits", "Petabytes" };
                addingAndRemovingCBItems(dataoptions);
            }

            if (conversioncb.Text == "Frequency")
            {
                string[] timeoptions = { "Microhertz", "Hertz", "Kilohertz", "Megahertz", "Gigahertz" };
                addingAndRemovingCBItems(timeoptions);
            }

            if (conversioncb.Text == "Length")
            {
                string[] lengthoptions = { "Nanometers", "Microns", "Millimeters", "Centimeters", "Meters", "Kilometers", "Inches", "Feet", "Yards", "Miles", "Nautical Miles" };
                addingAndRemovingCBItems(lengthoptions);
            }

            if (conversioncb.Text == "Pressure")
            {
                string[] timeoptions = { "Pascals", "Kilopascals", "MegaPascals" };
                addingAndRemovingCBItems(timeoptions);
            }

            if (conversioncb.Text == "Temperature")
            {
                string[] temperatureoptions = { "Celsius", "Fahrenheit", "Kelvin" };
                addingAndRemovingCBItems(temperatureoptions);
            }

            if (conversioncb.Text == "Volume")
            {
                string[] volumeoptions = { "Milliliters", "Cubic Centimeters", "Liters", "Cubic Meters", "Cubic Inches", "Cubic Feet", "Cubic Yards" };
                addingAndRemovingCBItems(volumeoptions);
            }

            if (conversioncb.Text == "Weight/Mass")
            {
                string[] weight_massoptions = { "Milligrams", "Centigrams", "Decigrams", "Grams", "Decagrams", "Hectograms", "Kilograms", "Metric Tonnes", "Ounces", "Pounds", "Stone" };
                addingAndRemovingCBItems(weight_massoptions);
            }
        }
        //END: Code for the Conversion ComboBox Options (25/09/17) - A

        //START: Code of Methods for the Conversions ComboBox Options (25/09/17) - A
        public double angleMethods(double input)
        {
                //same conversions
                if (conversioninputcb.Text == conversionoutputcb.Text) return input;
                //radians to degrees and degrees to radians
                if (conversioninputcb.Text == "Degrees" && conversionoutputcb.Text == "Radians")
                {
                    return input * (Math.PI / 180);
                }
                if (conversioninputcb.Text == "Radians" && conversionoutputcb.Text == "Degrees")
                {
                    return input * (180 / Math.PI);
                }
                //degrees to gradians and gradians to degrees
                if (conversioninputcb.Text == "Gradians" && conversionoutputcb.Text == "Degrees")
                {
                    return input * 9 / 10;
                }

                if (conversioninputcb.Text == "Degrees" && conversionoutputcb.Text == "Gradians")
                {
                    return input * 10 / 9;
                }

                //radians to gradians and gradians to degrees
                if (conversioninputcb.Text == "Gradians" && conversionoutputcb.Text == "Radians")
                {
                    return input * (Math.PI / 200);
                }

                if (conversioninputcb.Text == "Radians" && conversionoutputcb.Text == "Gradians")
                {
                    return input * (200 / Math.PI);
                }
            return -1;
        }

        public double areaMethods(double input)
        {
            //same conversions
            if (conversioninputcb.Text == conversionoutputcb.Text)
            {
                return input;
            }
            //Acres to Hectares, Square Centimeter, Square Feet, Square Inch, Square Metre, Square Mile, Square Millimetre, Square Yard
            if (conversioninputcb.Text == "Acres")
            {
                if (conversionoutputcb.Text == "Hectares")
                {
                    return input * 0.404685642;
                }
                else if (conversionoutputcb.Text == "Square Centimetre")
                {
                    return input / 0.000000024711;
                }
                else if (conversionoutputcb.Text == "Square Feet")
                {
                    return input * 43560;
                }
                else if (conversionoutputcb.Text == "Square Inch")
                {
                    return input * 6272640;
                }
                else if (conversionoutputcb.Text == "Square Metre")
                {
                    return input * 4046.85642;
                }
                else if (conversionoutputcb.Text == "Square Mile")
                {
                    return input * 0.0015625;
                }
                else if (conversionoutputcb.Text == "Square Millimetre")
                {
                    return input * 4046856420;
                }
                else if (conversionoutputcb.Text == "Square Yard")
                {
                    return input * 4840;
                }
            }
            //Hectares to other areas conversion
            if (conversioninputcb.Text == "Hectares")
            {
                if (conversionoutputcb.Text == "Acres")
                {
                    return input * 2.47105381;
                }
                else if (conversionoutputcb.Text == "Square Centimetre")
                {
                    return input * 100000000;
                }
                else if (conversionoutputcb.Text == "Square Feet")
                {
                    return input / 0.000009290304;
                }
                else if (conversionoutputcb.Text == "Square Inch")
                {
                    return input / 0.000000064516;
                }
                else if (conversionoutputcb.Text == "Square Metre")
                {
                    return input * 10000;
                }
                else if (conversionoutputcb.Text == "Square Mile")
                {
                    return input / 258.998811;
                }
                else if (conversionoutputcb.Text == "Square Millimetre")
                {
                    return input * 10000000000;
                }
                else if (conversionoutputcb.Text == "Square Yard")
                {
                    return input / 0.000083612736;
                }

            }
            if (conversioninputcb.Text == "Square Centimetre")
            {
                if (conversionoutputcb.Text == "Acres")
                {
                    return input / 40468564.2;
                }
                else if (conversionoutputcb.Text == "Hectare")
                {
                    return input / 100000000;
                }
                else if (conversionoutputcb.Text == "Square Feet")
                {
                    return input / 929.0304;
                }
                else if (conversionoutputcb.Text == "Square Inch")
                {
                    return input / 6.4516;
                }
                else if (conversionoutputcb.Text == "Square Metre")
                {
                    return input / 10000;
                }
                else if (conversionoutputcb.Text == "Square Mile")
                {
                    return input / 25899881100;
                }
                else if (conversionoutputcb.Text == "Square Millimetre")
                {
                    return input * 100;
                }
                else if (conversionoutputcb.Text == "Square Yard")
                {
                    return input / 8361.2736;
                }
            }
            if (conversioninputcb.Text == "Square Feet")
            {
                if (conversionoutputcb.Text == "Acres")
                {
                    return input / 43560;
                }
                else if (conversionoutputcb.Text == "Hectare")
                {
                    return input * 0.000009290304;
                }
                else if (conversionoutputcb.Text == "Square Centimetres")
                {
                    return input * 929.0304;
                }
                else if (conversionoutputcb.Text == "Square Inch")
                {
                    return input * 144;
                }
                else if (conversionoutputcb.Text == "Square Metre")
                {
                    return input * 0.09290304;
                }
                else if (conversionoutputcb.Text == "Square Mile")
                {
                    return input / 27878400;
                }
                else if (conversionoutputcb.Text == "Square Millimetre")
                {
                    return input * 92903.04;
                }
                else if (conversionoutputcb.Text == "Square Yard")
                {
                    return input / 9;
                }
            }
            if (conversioninputcb.Text == "Square Inch")
            {
                if (conversionoutputcb.Text == "Acres")
                {
                    return input / 6272640;
                }
                else if (conversionoutputcb.Text == "Hectare")
                {
                    return input * 0.000000064516;
                }
                else if (conversionoutputcb.Text == "Square Centimetres")
                {
                    return input * 6.4516;
                }
                else if (conversionoutputcb.Text == "Square Feet")
                {
                    return input / 144;
                }
                else if (conversionoutputcb.Text == "Square Metre")
                {
                    return input * 0.00064516;
                }
                else if (conversionoutputcb.Text == "Square Mile")
                {
                    return input / 4014489600;
                }
                else if (conversionoutputcb.Text == "Square Millimetre")
                {
                    return input * 645.16;
                }
                else if (conversionoutputcb.Text == "Square Yard")
                {
                    return input / 1296;
                }
            }
            if (conversioninputcb.Text == "Square Metre")
            {
                if (conversionoutputcb.Text == "Acres")
                {
                    return input / 4046.85642;
                }
                else if (conversionoutputcb.Text == "Hectare")
                {
                    return input / 10000;
                }
                else if (conversionoutputcb.Text == "Square Centimetres")
                {
                    return input * 10000;
                }
                else if (conversionoutputcb.Text == "Square Feet")
                {
                    return input / 0.09290304;
                }
                else if (conversionoutputcb.Text == "Square Inch")
                {
                    return input / 0.00064516;
                }
                else if (conversionoutputcb.Text == "Square Mile")
                {
                    return input / 2589988.11;
                }
                else if (conversionoutputcb.Text == "Square Millimetre")
                {
                    return input * 1000000;
                }
                else if (conversionoutputcb.Text == "Square Yard")
                {
                    return input / 0.83612736;
                }
            }
            if (conversioninputcb.Text == "Square Mile")
            {
                if (conversionoutputcb.Text == "Acres")
                {
                    return input * 640;
                }
                else if (conversionoutputcb.Text == "Hectare")
                {
                    return input * 258.998811;
                }
                else if (conversionoutputcb.Text == "Square Centimetres")
                {
                    return input * 25899881100;
                }
                else if (conversionoutputcb.Text == "Square Feet")
                {
                    return input * 27878400;
                }
                else if (conversionoutputcb.Text == "Square Inch")
                {
                    return input * 4014489600;
                }
                else if (conversionoutputcb.Text == "Square Metre")
                {
                    return input * 2589988.11;
                }
                else if (conversionoutputcb.Text == "Square Millimetre")
                {
                    return input * 2589988110000;
                }
                else if (conversionoutputcb.Text == "Square Yard")
                {
                    return input * 3097600;
                }
            }
            if (conversioninputcb.Text == "Square Millimetre")
            {
                if (conversionoutputcb.Text == "Acres")
                {
                    return input / 4046856420;
                }
                else if (conversionoutputcb.Text == "Hectare")
                {
                    return input / 10000000000;
                }
                else if (conversionoutputcb.Text == "Square Centimetres")
                {
                    return input / 100;
                }
                else if (conversionoutputcb.Text == "Square Feet")
                {
                    return input / 92903.04;
                }
                else if (conversionoutputcb.Text == "Square Inch")
                {
                    return input / 645.16;
                }
                else if (conversionoutputcb.Text == "Square Metre")
                {
                    return input / 1000000;
                }
                else if (conversionoutputcb.Text == "Square Mile")
                {
                    return input / 2589988110000;
                }
                else if (conversionoutputcb.Text == "Square Yard")
                {
                    return input / 836127.36;
                }
            }
            if (conversioninputcb.Text == "Square Yard")
            {
                if (conversionoutputcb.Text == "Acres")
                {
                    return input / 4840;
                }
                else if (conversionoutputcb.Text == "Hectare")
                {
                    return input * 0.000083612736;
                }
                else if (conversionoutputcb.Text == "Square Centimetres")
                {
                    return input * 8361.2736;
                }
                else if (conversionoutputcb.Text == "Square Feet")
                {
                    return input * 9;
                }
                else if (conversionoutputcb.Text == "Square Inch")
                {
                    return input * 1296;
                }
                else if (conversionoutputcb.Text == "Square Metre")
                {
                    return input * 0.83612736;
                }
                else if (conversionoutputcb.Text == "Square Mile")
                {
                    return input / 3097600;
                }
                else if (conversionoutputcb.Text == "Square Millimetre")
                {
                    return input * 836127.36;
                }
            }
            return -1;
        }

        public double dataStorageMethods(double input)
        {
            if (conversioninputcb.Text == conversionoutputcb.Text)
            {
                return input;
            }
            if (conversioninputcb.Text == "Bits")
            {
                if (conversionoutputcb.Text == "Bytes")
                {
                    return input / 8;
                }
                else if (conversionoutputcb.Text == "Kilobits")
                {
                    return input / 1024;
                }
                else if (conversionoutputcb.Text == "Kilobytes")
                {
                    return input / 8192;
                }
                else if (conversionoutputcb.Text == "Megabits")
                {
                    return input / 1048576;
                }
                else if (conversionoutputcb.Text == "Megabytes")
                {
                    return input / 8388608;
                }
                else if (conversionoutputcb.Text == "Gigabits")
                {
                    return input / 1073741824;
                }
                else if (conversionoutputcb.Text == "Gigabytes")
                {
                    return input / 8589934592;
                }
                else if (conversionoutputcb.Text == "Terabits")
                {
                    return input / 1099511627776;
                }
                else if (conversionoutputcb.Text == "Terabytes")
                {
                    return input / 8796093022208;
                }
                else if (conversionoutputcb.Text == "Petabits")
                {
                    return input / 1125899906842620;
                }
                else if (conversionoutputcb.Text == "Petabytes")
                {
                    return input / 9007199254740990;
                }
            }
            if (conversioninputcb.Text == "Bytes")
            {
                if (conversionoutputcb.Text == "Bits")
                {
                    return input * 8;
                }
                else if (conversionoutputcb.Text == "Kilobits")
                {
                    return input / 128;
                }
                else if (conversionoutputcb.Text == "Kilobytes")
                {
                    return input / 1024;
                }
                else if (conversionoutputcb.Text == "Megabits")
                {
                    return input / 131072;
                }
                else if (conversionoutputcb.Text == "Megabytes")
                {
                    return input / 1048576;
                }
                else if (conversionoutputcb.Text == "Gigabits")
                {
                    return input / 134217728;
                }
                else if (conversionoutputcb.Text == "Gigabytes")
                {
                    return input / 1073741824;
                }
                else if (conversionoutputcb.Text == "Terabits")
                {
                    return input / 137438953472;
                }
                else if (conversionoutputcb.Text == "Terabytes")
                {
                    return input / 1099511627776;
                }
                else if (conversionoutputcb.Text == "Petabits")
                {
                    return input / 140737488355328;
                }
                else if (conversionoutputcb.Text == "Petabytes")
                {
                    return input / 1125899906842620;
                }
            }
            if (conversioninputcb.Text == "Kilobits")
            {
                if (conversionoutputcb.Text == "Bits")
                {
                    return input * 1024;
                }
                else if (conversionoutputcb.Text == "Bytes")
                {
                    return input * 128;
                }
                else if (conversionoutputcb.Text == "Kilobytes")
                {
                    return input / 8;
                }
                else if (conversionoutputcb.Text == "Megabits")
                {
                    return input / 1024;
                }
                else if (conversionoutputcb.Text == "Megabytes")
                {
                    return input / 8192;
                }
                else if (conversionoutputcb.Text == "Gigabits")
                {
                    return input / 1048576;
                }
                else if (conversionoutputcb.Text == "Gigabytes")
                {
                    return input / 8388608;
                }
                else if (conversionoutputcb.Text == "Terabits")
                {
                    return input / 1073741824;
                }
                else if (conversionoutputcb.Text == "Terabytes")
                {
                    return input / 8589934592;
                }
                else if (conversionoutputcb.Text == "Petabits")
                {
                    return input / 1099511627776;
                }
                else if (conversionoutputcb.Text == "Petabytes")
                {
                    return input / 8796093022208;
                }
            }
            if (conversioninputcb.Text == "Kilobytes")
            {
                if (conversionoutputcb.Text == "Bits")
                {
                    return input / 8192;
                }
                else if (conversionoutputcb.Text == "Bytes")
                {
                    return input * 1024;
                }
                else if (conversionoutputcb.Text == "Kilobits")
                {
                    return input * 8;
                }
                else if (conversionoutputcb.Text == "Megabits")
                {
                    return input / 128;
                }
                else if (conversionoutputcb.Text == "Megabytes")
                {
                    return input / 1024;
                }
                else if (conversionoutputcb.Text == "Gigabits")
                {
                    return input / 131072;
                }
                else if (conversionoutputcb.Text == "Gigabytes")
                {
                    return input / 1048576;
                }
                else if (conversionoutputcb.Text == "Terabits")
                {
                    return input / 134217728;
                }
                else if (conversionoutputcb.Text == "Terabytes")
                {
                    return input / 1073741824;
                }
                else if (conversionoutputcb.Text == "Petabits")
                {
                    return input / 137438953472;
                }
                else if (conversionoutputcb.Text == "Petabytes")
                {
                    return input / 1099511627776;
                }
            }
            if (conversioninputcb.Text == "Megabits")
            {
                if (conversionoutputcb.Text == "Bits")
                {
                    return input * 1048576;
                }
                else if (conversionoutputcb.Text == "Bytes")
                {
                    return input * 131072;
                }
                else if (conversionoutputcb.Text == "Kilobits")
                {
                    return input * 1024;
                }
                else if (conversionoutputcb.Text == "Kilobytes")
                {
                    return input * 128;
                }
                else if (conversionoutputcb.Text == "Megabytes")
                {
                    return input / 8;
                }
                else if (conversionoutputcb.Text == "Gigabits")
                {
                    return input / 1024;
                }
                else if (conversionoutputcb.Text == "Gigabytes")
                {
                    return input / 8192;
                }
                else if (conversionoutputcb.Text == "Terabits")
                {
                    return input / 1048576;
                }
                else if (conversionoutputcb.Text == "Terabytes")
                {
                    return input / 8388608;
                }
                else if (conversionoutputcb.Text == "Petabits")
                {
                    return input / 1073741824;
                }
                else if (conversionoutputcb.Text == "Petabytes")
                {
                    return input / 8589934592;
                }
            }
            if (conversioninputcb.Text == "Megabytes")
            {
                if (conversionoutputcb.Text == "Bits")
                {
                    return input * 8388608;
                }
                else if (conversionoutputcb.Text == "Bytes")
                {
                    return input * 1048576;
                }
                else if (conversionoutputcb.Text == "Kilobits")
                {
                    return input * 8192;
                }
                else if (conversionoutputcb.Text == "Kilobytes")
                {
                    return input * 1024;
                }
                else if (conversionoutputcb.Text == "Megabits")
                {
                    return input * 8;
                }
                else if (conversionoutputcb.Text == "Gigabits")
                {
                    return input / 128;
                }
                else if (conversionoutputcb.Text == "Gigabytes")
                {
                    return input / 1024;
                }
                else if (conversionoutputcb.Text == "Terabits")
                {
                    return input / 131072;
                }
                else if (conversionoutputcb.Text == "Terabytes")
                {
                    return input / 1048576;
                }
                else if (conversionoutputcb.Text == "Petabits")
                {
                    return input / 134217728;
                }
                else if (conversionoutputcb.Text == "Petabytes")
                {
                    return input / 1073741824;
                }
            }
            if (conversioninputcb.Text == "Gigabits")
            {
                if (conversionoutputcb.Text == "Bits")
                {
                    return input * 1073741824;
                }
                else if (conversionoutputcb.Text == "Bytes")
                {
                    return input * 134217728;
                }
                else if (conversionoutputcb.Text == "Kilobits")
                {
                    return input * 1048576;
                }
                else if (conversionoutputcb.Text == "Kilobytes")
                {
                    return input * 131072;
                }
                else if (conversionoutputcb.Text == "Megabits")
                {
                    return input * 1024;
                }
                else if (conversionoutputcb.Text == "Megabytes")
                {
                    return input * 128;
                }
                else if (conversionoutputcb.Text == "Gigabytes")
                {
                    return input / 8;
                }
                else if (conversionoutputcb.Text == "Terabits")
                {
                    return input / 1024;
                }
                else if (conversionoutputcb.Text == "Terabytes")
                {
                    return input / 8192;
                }
                else if (conversionoutputcb.Text == "Petabits")
                {
                    return input / 1048576;
                }
                else if (conversionoutputcb.Text == "Petabytes")
                {
                    return input / 8388608;
                }
            }
            if (conversioninputcb.Text == "Gigabytes")
            {
                if (conversionoutputcb.Text == "Bits")
                {
                    return input * 8589934592;
                }
                else if (conversionoutputcb.Text == "Bytes")
                {
                    return input * 1073741824;
                }
                else if (conversionoutputcb.Text == "Kilobits")
                {
                    return input * 8388608;
                }
                else if (conversionoutputcb.Text == "Kilobytes")
                {
                    return input * 1048576;
                }
                else if (conversionoutputcb.Text == "Megabits")
                {
                    return input * 8192;
                }
                else if (conversionoutputcb.Text == "Megabytes")
                {
                    return input * 1024;
                }
                else if (conversionoutputcb.Text == "Gigabits")
                {
                    return input * 8;
                }
                else if (conversionoutputcb.Text == "Terabits")
                {
                    return input / 128;
                }
                else if (conversionoutputcb.Text == "Terabytes")
                {
                    return input / 1024;
                }
                else if (conversionoutputcb.Text == "Petabits")
                {
                    return input / 131072;
                }
                else if (conversionoutputcb.Text == "Petabytes")
                {
                    return input / 1048576;
                }
            }
            if (conversioninputcb.Text == "Terabits")
            {
                if (conversionoutputcb.Text == "Bits")
                {
                    return input * 1099511627776;
                }
                else if (conversionoutputcb.Text == "Bytes")
                {
                    return input * 137438953472;
                }
                else if (conversionoutputcb.Text == "Kilobits")
                {
                    return input * 1073741824;
                }
                else if (conversionoutputcb.Text == "Kilobytes")
                {
                    return input * 134217728;
                }
                else if (conversionoutputcb.Text == "Megabits")
                {
                    return input * 1048576;
                }
                else if (conversionoutputcb.Text == "Megabytes")
                {
                    return input * 131072;
                }
                else if (conversionoutputcb.Text == "Gigabits")
                {
                    return input * 1024;
                }
                else if (conversionoutputcb.Text == "Gigabytes")
                {
                    return input * 128;
                }
                else if (conversionoutputcb.Text == "Terabytes")
                {
                    return input / 8;
                }
                else if (conversionoutputcb.Text == "Petabits")
                {
                    return input / 1024;
                }
                else if (conversionoutputcb.Text == "Petabytes")
                {
                    return input / 8192;
                }
            }
            if (conversioninputcb.Text == "Terabytes")
            {
                if (conversionoutputcb.Text == "Bits")
                {
                    return input * 8796093022208;
                }
                else if (conversionoutputcb.Text == "Bytes")
                {
                    return input * 1099511627776;
                }
                else if (conversionoutputcb.Text == "Kilobits")
                {
                    return input * 8589934592;
                }
                else if (conversionoutputcb.Text == "Kilobytes")
                {
                    return input * 1073741824;
                }
                else if (conversionoutputcb.Text == "Megabits")
                {
                    return input * 8388608;
                }
                else if (conversionoutputcb.Text == "Megabytes")
                {
                    return input * 1048576;
                }
                else if (conversionoutputcb.Text == "Gigabits")
                {
                    return input * 8192;
                }
                else if (conversionoutputcb.Text == "Gigabytes")
                {
                    return input * 1024;
                }
                else if (conversionoutputcb.Text == "Terabits")
                {
                    return input * 8;
                }
                else if (conversionoutputcb.Text == "Petabits")
                {
                    return input / 128;
                }
                else if (conversionoutputcb.Text == "Petabytes")
                {
                    return input / 1024;
                }
            }
            if (conversioninputcb.Text == "Petabits")
            {
                if (conversionoutputcb.Text == "Bits")
                {
                    return input * 1125899906842620;
                }
                else if (conversionoutputcb.Text == "Bytes")
                {
                    return input * 140737488355328;
                }
                else if (conversionoutputcb.Text == "Kilobits")
                {
                    return input * 1099511627776;
                }
                else if (conversionoutputcb.Text == "Kilobytes")
                {
                    return input * 137438953472;
                }
                else if (conversionoutputcb.Text == "Megabits")
                {
                    return input * 1073741824;
                }
                else if (conversionoutputcb.Text == "Megabytes")
                {
                    return input * 134217728;
                }
                else if (conversionoutputcb.Text == "Gigabits")
                {
                    return input * 1048576;
                }
                else if (conversionoutputcb.Text == "Gigabytes")
                {
                    return input * 131072;
                }
                else if (conversionoutputcb.Text == "Terabits")
                {
                    return input * 1024;
                }
                else if (conversionoutputcb.Text == "Terabytes")
                {
                    return input * 128;
                }
                else if (conversionoutputcb.Text == "Petabytes")
                {
                    return input / 8;
                }
            }
            if (conversioninputcb.Text == "Petabytes")
            {
                if (conversionoutputcb.Text == "Bits")
                {
                    return input * 9007199254740990;
                }
                else if (conversionoutputcb.Text == "Bytes")
                {
                    return input * 1125899906842620;
                }
                else if (conversionoutputcb.Text == "Kilobits")
                {
                    return input * 8796093022208;
                }
                else if (conversionoutputcb.Text == "Kilobytes")
                {
                    return input * 1099511627776;
                }
                else if (conversionoutputcb.Text == "Megabits")
                {
                    return input * 8589934592;
                }
                else if (conversionoutputcb.Text == "Megabytes")
                {
                    return input * 1073741824;
                }
                else if (conversionoutputcb.Text == "Gigabits")
                {
                    return input * 8388608;
                }
                else if (conversionoutputcb.Text == "Gigabytes")
                {
                    return input * 1048576;
                }
                else if (conversionoutputcb.Text == "Terabits")
                {
                    return input * 8192;
                }
                else if (conversionoutputcb.Text == "Terabytes")
                {
                    return input * 1024;
                }
                else if (conversionoutputcb.Text == "Petabits")
                {
                    return input * 8;
                }
            }
            return -1;
        }

        public double frequencyMethods(double input)
        {
            if (conversioninputcb.Text == conversionoutputcb.Text)
            {
                return input;
            }
            if (conversioninputcb.Text == "Microhertz")
            {
                if (conversionoutputcb.Text == "Hertz")
                {
                    return input / 1000000;
                }
                else if (conversionoutputcb.Text == "Kilohertz")
                {
                    return input / 1000000000;
                }
                else if (conversionoutputcb.Text == "Megahertz")
                {
                    return input / 1000000000000;
                }
                else if (conversionoutputcb.Text == "Gigahertz")
                {
                    return input / 1000000000000000;
                }
            }
            if (conversioninputcb.Text == "Hertz")
            {
                if (conversionoutputcb.Text == "Microhertz")
                {
                    return input * 1000000;
                }
                else if (conversionoutputcb.Text == "Kilohertz")
                {
                    return input / 1000;
                }
                else if (conversionoutputcb.Text == "Megahertz")
                {
                    return input / 1000000;
                }
                else if (conversionoutputcb.Text == "Gigahertz")
                {
                    return input / 1000000000;
                }
            }
            if (conversioninputcb.Text == "Kilohertz")
            {
                if (conversionoutputcb.Text == "Microhertz")
                {
                    return input * 1000000000;
                }
                else if (conversionoutputcb.Text == "Hertz")
                {
                    return input * 1000;
                }
                else if (conversionoutputcb.Text == "Megahertz")
                {
                    return input / 1000;
                }
                else if (conversionoutputcb.Text == "Gigahertz")
                {
                    return input / 1000000;
                }
            }
            if (conversioninputcb.Text == "Megahertz")
            {
                if (conversionoutputcb.Text == "Microhertz")
                {
                    return input * 1000000000000;
                }
                else if (conversionoutputcb.Text == "Hertz")
                {
                    return input * 1000000;
                }
                else if (conversionoutputcb.Text == "Kilohertz")
                {
                    return input * 1000;
                }
                else if (conversionoutputcb.Text == "Gigahertz")
                {
                    return input / 1000;
                }
            }
            if (conversioninputcb.Text == "Gigahertz")
            {
                if (conversionoutputcb.Text == "Microhertz")
                {
                    return input * 1000000000000000;
                }
                else if (conversionoutputcb.Text == "Hertz")
                {
                    return input * 1000000000;
                }
                else if (conversionoutputcb.Text == "Kilohertz")
                {
                    return input * 1000000;
                }
                else if (conversionoutputcb.Text == "Megahertz")
                {
                    return input * 1000;
                }
            }
            return -1;
        }

        public double lengthMethods(double input)
        {
            if (conversioninputcb.Text == conversionoutputcb.Text)
            {
                return input;
            }
            if (conversioninputcb.Text == "Nanometers")
            {
                if (conversionoutputcb.Text == "Microns")
                {
                    return input * 0.0010;
                }
                else if (conversionoutputcb.Text == "Millimeters")
                {
                    return input / 1000000;
                }
                else if (conversionoutputcb.Text == "Centimeters")
                {
                    return input / 10000000;
                }
                else if (conversionoutputcb.Text == "Meters")
                {
                    return input / 1000000000;
                }
                else if (conversionoutputcb.Text == "Kilometers")
                {
                    return input / 1000000000000;
                }
                else if (conversionoutputcb.Text == "Inches")
                {
                    return input / 25400000;
                }
                else if (conversionoutputcb.Text == "Feet")
                {
                    return input / 304800000;
                }
                else if (conversionoutputcb.Text == "Yards")
                {
                    return input / 914400000;
                }
                else if (conversionoutputcb.Text == "Miles")
                {
                    return input / 1609344000000;
                }
                else if (conversionoutputcb.Text == "Nautical Miles")
                {
                    return input / 1852000000000;
                }
            }
            if (conversioninputcb.Text == "Microns")
            {
                if (conversionoutputcb.Text == "Nanometers")
                {
                    return input * 1000;
                }
                else if (conversionoutputcb.Text == "Millimeters")
                {
                    return input * 0.0010;
                }
                else if (conversionoutputcb.Text == "Centimeters")
                {
                    return input * 0.00010;
                }
                else if (conversionoutputcb.Text == "Meters")
                {
                    return input * 0.0000010;
                }
                else if (conversionoutputcb.Text == "Kilometers")
                {
                    return input * 0.0000000010;
                }
                else if (conversionoutputcb.Text == "Inches")
                {
                    return input * 0.000039;
                }
                else if (conversionoutputcb.Text == "Feet")
                {
                    return input * 0.0000033;
                }
                else if (conversionoutputcb.Text == "Yards")
                {
                    return input * 0.0000011;
                }
                else if (conversionoutputcb.Text == "Miles")
                {
                    return input * 0.00000000062;
                }
                else if (conversionoutputcb.Text == "Nautical Miles")
                {
                    return input * 0.00000000054;
                }
            }
            if (conversioninputcb.Text == "Millimeters")
            {
                if (conversionoutputcb.Text == "Nanometers")
                {
                    return input * 1000000;
                }
                else if (conversionoutputcb.Text == "Microns")
                {
                    return input * 1000;
                }
                else if (conversionoutputcb.Text == "Centimeters")
                {
                    return input / 10;
                }
                else if (conversionoutputcb.Text == "Meters")
                {
                    return input / 1000;
                }
                else if (conversionoutputcb.Text == "Kilometers")
                {
                    return input / 1000000;
                }
                else if (conversionoutputcb.Text == "Inches")
                {
                    return input / 25.4;
                }
                else if (conversionoutputcb.Text == "Feet")
                {
                    return input / 304.8;
                }
                else if (conversionoutputcb.Text == "Yards")
                {
                    return input / 914.4;
                }
                else if (conversionoutputcb.Text == "Miles")
                {
                    return input / 1609344;
                }
                else if (conversionoutputcb.Text == "Nautical Miles")
                {
                    return input / 1852000;
                }
            }
            if (conversioninputcb.Text == "Centimeters")
            {
                if (conversionoutputcb.Text == "Nanometers")
                {
                    return input * 10000000;
                }
                else if (conversionoutputcb.Text == "Microns")
                {
                    return input * 10000;
                }
                else if (conversionoutputcb.Text == "Millimeters")
                {
                    return input * 10;
                }
                else if (conversionoutputcb.Text == "Meters")
                {
                    return input / 100;
                }
                else if (conversionoutputcb.Text == "Kilometers")
                {
                    return input / 100000;
                }
                else if (conversionoutputcb.Text == "Inches")
                {
                    return input / 2.54;
                }
                else if (conversionoutputcb.Text == "Feet")
                {
                    return input / 30.48;
                }
                else if (conversionoutputcb.Text == "Yards")
                {
                    return input / 91.44;
                }
                else if (conversionoutputcb.Text == "Miles")
                {
                    return input / 160934.4;
                }
                else if (conversionoutputcb.Text == "Nautical Miles")
                {
                    return input / 185200;
                }
            }
            if (conversioninputcb.Text == "Meters")
            {
                if (conversionoutputcb.Text == "Nanometers")
                {
                    return input * 1000000000;
                }
                else if (conversionoutputcb.Text == "Microns")
                {
                    return input * 1000000;
                }
                else if (conversionoutputcb.Text == "Millimeters")
                {
                    return input * 1000;
                }
                else if (conversionoutputcb.Text == "Centimeters")
                {
                    return input * 100;
                }
                else if (conversionoutputcb.Text == "Kilometers")
                {
                    return input / 1000;
                }
                else if (conversionoutputcb.Text == "Inches")
                {
                    return input / 0.0254;
                }
                else if (conversionoutputcb.Text == "Feet")
                {
                    return input / 0.3048;
                }
                else if (conversionoutputcb.Text == "Yards")
                {
                    return input / 0.9144;
                }
                else if (conversionoutputcb.Text == "Miles")
                {
                    return input / 1609.344;
                }
                else if (conversionoutputcb.Text == "Nautical Miles")
                {
                    return input / 1852;
                }
            }
            if (conversioninputcb.Text == "Kilometers")
            {
                if (conversionoutputcb.Text == "Nanometers")
                {
                    return input * 1000000000000;
                }
                else if (conversionoutputcb.Text == "Microns")
                {
                    return input * 1000000000;
                }
                else if (conversionoutputcb.Text == "Millimeters")
                {
                    return input * 1000000;
                }
                else if (conversionoutputcb.Text == "Centimeters")
                {
                    return input * 100000;
                }
                else if (conversionoutputcb.Text == "Meters")
                {
                    return input * 1000;
                }
                else if (conversionoutputcb.Text == "Inches")
                {
                    return input / 0.0000254;
                }
                else if (conversionoutputcb.Text == "Feet")
                {
                    return input / 0.0003048;
                }
                else if (conversionoutputcb.Text == "Yards")
                {
                    return input / 0.0009144;
                }
                else if (conversionoutputcb.Text == "Miles")
                {
                    return input / 1.609344;
                }
                else if (conversionoutputcb.Text == "Nautical Miles")
                {
                    return input / 1.852;
                }
            }
            if (conversioninputcb.Text == "Inches")
            {
                if (conversionoutputcb.Text == "Nanometers")
                {
                    return input * 25400000;
                }
                else if (conversionoutputcb.Text == "Microns")
                {
                    return input * 25400;
                }
                else if (conversionoutputcb.Text == "Millimeters")
                {
                    return input * 25.4;
                }
                else if (conversionoutputcb.Text == "Centimeters")
                {
                    return input * 2.54;
                }
                else if (conversionoutputcb.Text == "Meters")
                {
                    return input * 0.0254;
                }
                else if (conversionoutputcb.Text == "Kilometers")
                {
                    return input * 0.0000254;
                }
                else if (conversionoutputcb.Text == "Feet")
                {
                    return input / 12;
                }
                else if (conversionoutputcb.Text == "Yards")
                {
                    return input / 36;
                }
                else if (conversionoutputcb.Text == "Miles")
                {
                    return input / 63360;
                }
                else if (conversionoutputcb.Text == "Nautical Miles")
                {
                    return input / 72913.3858;
                }
            }
            if (conversioninputcb.Text == "Feet")
            {
                if (conversionoutputcb.Text == "Nanometers")
                {
                    return input * 304800000;
                }
                else if (conversionoutputcb.Text == "Microns")
                {
                    return input * 304800;
                }
                else if (conversionoutputcb.Text == "Millimeters")
                {
                    return input * 304.8;
                }
                else if (conversionoutputcb.Text == "Centimeters")
                {
                    return input * 30.48;
                }
                else if (conversionoutputcb.Text == "Meters")
                {
                    return input * 0.3048;
                }
                else if (conversionoutputcb.Text == "Kilometers")
                {
                    return input * 0.0003048;
                }
                else if (conversionoutputcb.Text == "Inches")
                {
                    return input * 12;
                }
                else if (conversionoutputcb.Text == "Yards")
                {
                    return input / 3;
                }
                else if (conversionoutputcb.Text == "Miles")
                {
                    return input / 5280;
                }
                else if (conversionoutputcb.Text == "Nautical Miles")
                {
                    return input / 6076.11549;
                }
            }
            if (conversioninputcb.Text == "Yards")
            {
                if (conversionoutputcb.Text == "Nanometers")
                {
                    return input * 914400000;
                }
                else if (conversionoutputcb.Text == "Microns")
                {
                    return input * 914400;
                }
                else if (conversionoutputcb.Text == "Millimeters")
                {
                    return input * 914.4;
                }
                else if (conversionoutputcb.Text == "Centimeters")
                {
                    return input * 91.44;
                }
                else if (conversionoutputcb.Text == "Meters")
                {
                    return input * 0.9144;
                }
                else if (conversionoutputcb.Text == "Kilometers")
                {
                    return input * 0.0009144;
                }
                else if (conversionoutputcb.Text == "Inches")
                {
                    return input * 36;
                }
                else if (conversionoutputcb.Text == "Feet")
                {
                    return input * 3;
                }
                else if (conversionoutputcb.Text == "Miles")
                {
                    return input / 1760;
                }
                else if (conversionoutputcb.Text == "Nautical Miles")
                {
                    return input / 2025.37183;
                }
            }
            if (conversioninputcb.Text == "Miles")
            {
                if (conversionoutputcb.Text == "Nanometers")
                {
                    return input * 1609344000000;
                }
                else if (conversionoutputcb.Text == "Microns")
                {
                    return input * 1609344000;
                }
                else if (conversionoutputcb.Text == "Millimeters")
                {
                    return input * 1609344;
                }
                else if (conversionoutputcb.Text == "Centimeters")
                {
                    return input * 160934.4;
                }
                else if (conversionoutputcb.Text == "Meters")
                {
                    return input * 1609.344;
                }
                else if (conversionoutputcb.Text == "Kilometers")
                {
                    return input * 1.609344;
                }
                else if (conversionoutputcb.Text == "Inches")
                {
                    return input * 63360;
                }
                else if (conversionoutputcb.Text == "Feet")
                {
                    return input * 5280;
                }
                else if (conversionoutputcb.Text == "Yards")
                {
                    return input * 1760;
                }
                else if (conversionoutputcb.Text == "Nautical Miles")
                {
                    return input / 1.15078;
                }
            }
            if (conversioninputcb.Text == "Nautical Miles")
            {
                if (conversionoutputcb.Text == "Nanometers")
                {
                    return input * 1852000000000;
                }
                else if (conversionoutputcb.Text == "Microns")
                {
                    return input * 1852000000;
                }
                else if (conversionoutputcb.Text == "Millimeters")
                {
                    return input * 1852000;
                }
                else if (conversionoutputcb.Text == "Centimeters")
                {
                    return input * 185200;
                }
                else if (conversionoutputcb.Text == "Meters")
                {
                    return input * 1852;
                }
                else if (conversionoutputcb.Text == "Kilometers")
                {
                    return input * 1.852;
                }
                else if (conversionoutputcb.Text == "Inches")
                {
                    return input * 72913.3858;
                }
                else if (conversionoutputcb.Text == "Feet")
                {
                    return input * 6076.11549;
                }
                else if (conversionoutputcb.Text == "Yards")
                {
                    return input * 2025.37183;
                }
                else if (conversionoutputcb.Text == "Miles")
                {
                    return input * 1.15078;
                }
            }
            return -1;
        }

        public double pressureMethods(double input)
        {
            if (conversioninputcb.Text == conversionoutputcb.Text) return input;
            if (conversioninputcb.Text == "Pascals")
            {
                if (conversionoutputcb.Text == "Kilopascals")
                {
                    return input / 1000;
                }
                else if (conversionoutputcb.Text == "Megapascals")
                {
                    return input / 1000000;
                }
            }
            if (conversioninputcb.Text == "Kilopascals")
            {
                if (conversionoutputcb.Text == "Pascals")
                {
                    return input * 1000;
                }
                else if (conversionoutputcb.Text == "Megapascals")
                {
                    return input / 1000;
                }
            }
            if (conversioninputcb.Text == "Megapascals")
            {
                if (conversionoutputcb.Text == "Pascals")
                {
                    return input * 1000000;
                }
                else if (conversionoutputcb.Text == "Kilopascals")
                {
                    return input * 1000;
                }
            }
            return -1;
        }

        public double temperatureMethods(double input)
        {
            if (conversioninputcb.Text == conversionoutputcb.Text) return input;
            if (conversioninputcb.Text == "Celsius")
            {
                if (conversionoutputcb.Text == "Fahrenheit")
                {
                    return (input * 1.8) + 32;
                }
                else if (conversionoutputcb.Text == "Kelvin")
                {
                    return input + 273.15;
                }
            }
            if (conversioninputcb.Text == "Fahrenheit")
            {
                if (conversionoutputcb.Text == "Celsius")
                {
                    return (((input - 32) * 5) / 9);
                }
                else if (conversionoutputcb.Text == "Kelvin")
                {
                    return (((input - 32) * 5) / 9) + 273.15;
                }
            }
            if (conversioninputcb.Text == "Kelvin")
            {
                if (conversionoutputcb.Text == "Celsius")
                {
                    return input - 273.15;
                }
                else if (conversionoutputcb.Text == "Fahrenheit")
                {
                    return ((input - 273.15) * 1.8) + 32;
                }
            }
            return -1;
        }

        public double volumeMethods(double input)
        {
            if (conversioninputcb.Text == conversionoutputcb.Text)
            {
                return input;
            }
            if (conversioninputcb.Text == "Milliliters")
            {
                if (conversionoutputcb.Text == "Cubic Centimeters")
                {
                    return input / 1;
                }
                else if (conversionoutputcb.Text == "Liters")
                {
                    return input / 1000;
                }
                else if (conversionoutputcb.Text == "Cubic Meters")
                {
                    return input * 0.0000010;
                }
                else if (conversionoutputcb.Text == "Cubic Inches")
                {
                    return input * 0.061;
                }
                else if (conversionoutputcb.Text == "Cubic Feet")
                {
                    return input * 0.000035;
                }
                else if (conversionoutputcb.Text == "Cubic Yards")
                {
                    return input * 0.0000013;
                }
            }
            if (conversioninputcb.Text == "Cubic Centimeters")
            {
                if (conversionoutputcb.Text == "Millimeters")
                {
                    return input * 1;
                }
                else if (conversionoutputcb.Text == "Liters")
                {
                    return input / 1000;
                }
                else if (conversionoutputcb.Text == "Cubic Meters")
                {
                    return input / 1000000;
                }
                else if (conversionoutputcb.Text == "Cubic Inches")
                {
                    return input / 16.387064;
                }
                else if (conversionoutputcb.Text == "Cubic Feet")
                {
                    return input / 28316.8466;
                }
                else if (conversionoutputcb.Text == "Cubic Yards")
                {
                    return input / 764554.858;
                }
            }
            if (conversioninputcb.Text == "Litres")
            {
                if (conversionoutputcb.Text == "Millimeters" || conversionoutputcb.Text == "Cubic Centimeters")
                {
                    return input * 1000;
                }
                else if (conversionoutputcb.Text == "Cubic Meters")
                {
                    return input / 1000;
                }
                else if (conversionoutputcb.Text == "Cubic Inches")
                {
                    return input * 61.02;
                }
                else if (conversionoutputcb.Text == "Cubic Feet")
                {
                    return input * 0.035;
                }
                else if (conversionoutputcb.Text == "Cubic Yards")
                {
                    return input * 0.0013;
                }
            }
            if (conversioninputcb.Text == "Cubic Meters")
            {
                if (conversionoutputcb.Text == "Millimeters" || conversionoutputcb.Text == "Cubic Centimeters")
                {
                    return input * 1000000;
                }
                else if (conversionoutputcb.Text == "Litres")
                {
                    return input * 1000;
                }
                else if (conversionoutputcb.Text == "Cubic Inches")
                {
                    return input / 0.000016387064;
                }
                else if (conversionoutputcb.Text == "Cubic Feet")
                {
                    return input / 0.0283168466;
                }
                else if (conversionoutputcb.Text == "Cubic Yards")
                {
                    return input / 0.764554858;
                }
            }
            if (conversioninputcb.Text == "Cubic Inches")
            {
                if (conversionoutputcb.Text == "Millimeters" || conversionoutputcb.Text == "Cubic Centimeters")
                {
                    return input * 16.387064;
                }
                else if (conversionoutputcb.Text == "Litres")
                {
                    return input * 0.016;
                }
                else if (conversionoutputcb.Text == "Cubic Meters")
                {
                    return input * 0.000016387064;
                }
                else if (conversionoutputcb.Text == "Cubic Feet")
                {
                    return input / 1728;
                }
                else if (conversionoutputcb.Text == "Cubic Yards")
                {
                    return input / 46656;
                }
            }
            if (conversioninputcb.Text == "Cubic Feet")
            {
                if (conversionoutputcb.Text == "Millimeters" || conversionoutputcb.Text == "Cubic Centimeters")
                {
                    return input * 28316.8466;
                }
                else if (conversionoutputcb.Text == "Litres")
                {
                    return input * 28.32;
                }
                else if (conversionoutputcb.Text == "Cubic Meters")
                {
                    return input * 0.0283168466;
                }
                else if (conversionoutputcb.Text == "Cubic Inches")
                {
                    return input * 1728;
                }
                else if (conversionoutputcb.Text == "Cubic Yards")
                {
                    return input / 27;
                }
            }
            if (conversioninputcb.Text == "Cubic Yards")
            {
                if (conversionoutputcb.Text == "Millimeters" || conversionoutputcb.Text == "Cubic Centimeters")
                {
                    return input * 764554.858;
                }
                else if (conversionoutputcb.Text == "Litres")
                {
                    return input * 764.55;
                }
                else if (conversionoutputcb.Text == "Cubic Meters")
                {
                    return input * 0.764554858;
                }
                else if (conversionoutputcb.Text == "Cubic Inches")
                {
                    return input * 46656;
                }
                else if (conversionoutputcb.Text == "Cubic Feet")
                {
                    return input * 27;
                }
            }
            return -1;
        }

        public double weightmassMethods(double input)
        {
            if (conversioninputcb.Text == conversionoutputcb.Text)
            {
                return input;
            }
            if (conversioninputcb.Text == "Milligrams")
            {
                if (conversionoutputcb.Text == "Centigrams")
                {
                    return input / 10;
                }
                else if (conversionoutputcb.Text == "Decigrams")
                {
                    return input / 100;
                }
                else if (conversionoutputcb.Text == "Grams")
                {
                    return input / 1000;
                }
                else if (conversionoutputcb.Text == "Decagrams")
                {
                    return input / 10000;
                }
                else if (conversionoutputcb.Text == "Hectograms")
                {
                    return input / 100000;
                }
                else if (conversionoutputcb.Text == "Kilograms")
                {
                    return input / 1000000;
                }
                else if (conversionoutputcb.Text == "Metric Tonnes")
                {
                    return input / 1000000000;
                }
                else if (conversionoutputcb.Text == "Ounces")
                {
                    return input / 28349.5231;
                }
                else if (conversionoutputcb.Text == "Pounds")
                {
                    return input / 453592.37;
                }
                else if (conversionoutputcb.Text == "Stone")
                {
                    return input / 6350293.18;
                }
            }
            if (conversioninputcb.Text == "Centigrams")
            {
                if (conversionoutputcb.Text == "Milligrams")
                {
                    return input * 10;
                }
                else if (conversionoutputcb.Text == "Decigrams")
                {
                    return input / 10;
                }
                else if (conversionoutputcb.Text == "Grams")
                {
                    return input / 100;
                }
                else if (conversionoutputcb.Text == "Decagrams")
                {
                    return input / 1000;
                }
                else if (conversionoutputcb.Text == "Hectograms")
                {
                    return input / 10000;
                }
                else if (conversionoutputcb.Text == "Kilograms")
                {
                    return input / 100000;
                }
                else if (conversionoutputcb.Text == "Metric Tonnes")
                {
                    return input / 100000000;
                }
                else if (conversionoutputcb.Text == "Ounces")
                {
                    return input / 2834.95231;
                }
                else if (conversionoutputcb.Text == "Pounds")
                {
                    return input / 45359.237;
                }
                else if (conversionoutputcb.Text == "Stone")
                {
                    return input / 635029.318;
                }
            }
            if (conversioninputcb.Text == "Decigrams")
            {
                if (conversionoutputcb.Text == "Milligrams")
                {
                    return input * 100;
                }
                else if (conversionoutputcb.Text == "Centigrams")
                {
                    return input * 10;
                }
                else if (conversionoutputcb.Text == "Grams")
                {
                    return input / 10;
                }
                else if (conversionoutputcb.Text == "Decagrams")
                {
                    return input / 100;
                }
                else if (conversionoutputcb.Text == "Hectograms")
                {
                    return input / 1000;
                }
                else if (conversionoutputcb.Text == "Kilograms")
                {
                    return input / 10000;
                }
                else if (conversionoutputcb.Text == "Metric Tonnes")
                {
                    return input / 10000000;
                }
                else if (conversionoutputcb.Text == "Ounces")
                {
                    return input / 283.495231;
                }
                else if (conversionoutputcb.Text == "Pounds")
                {
                    return input / 4535.9237;
                }
                else if (conversionoutputcb.Text == "Stone")
                {
                    return input / 63502.9318;
                }
            }
            if (conversioninputcb.Text == "Grams")
            {
                if (conversionoutputcb.Text == "Milligrams")
                {
                    return input * 1000;
                }
                else if (conversionoutputcb.Text == "Centigrams")
                {
                    return input * 100;
                }
                else if (conversionoutputcb.Text == "Decigrams")
                {
                    return input * 10;
                }
                else if (conversionoutputcb.Text == "Decagrams")
                {
                    return input / 10;
                }
                else if (conversionoutputcb.Text == "Hectograms")
                {
                    return input / 100;
                }
                else if (conversionoutputcb.Text == "Kilograms")
                {
                    return input / 1000;
                }
                else if (conversionoutputcb.Text == "Metric Tonnes")
                {
                    return input / 1000000;
                }
                else if (conversionoutputcb.Text == "Ounces")
                {
                    return input / 28.3495231;
                }
                else if (conversionoutputcb.Text == "Pounds")
                {
                    return input / 453.59237;
                }
                else if (conversionoutputcb.Text == "Stone")
                {
                    return input / 6350.29318;
                }
            }
            if (conversioninputcb.Text == "Decagrams")
            {
                if (conversionoutputcb.Text == "Milligrams")
                {
                    return input * 10000;
                }
                else if (conversionoutputcb.Text == "Centigrams")
                {
                    return input * 1000;
                }
                else if (conversionoutputcb.Text == "Decigrams")
                {
                    return input * 100;
                }
                else if (conversionoutputcb.Text == "Grams")
                {
                    return input * 10;
                }
                else if (conversionoutputcb.Text == "Hectograms")
                {
                    return input / 10;
                }
                else if (conversionoutputcb.Text == "Kilograms")
                {
                    return input / 100;
                }
                else if (conversionoutputcb.Text == "Metric Tonnes")
                {
                    return input / 100000;
                }
                else if (conversionoutputcb.Text == "Ounces")
                {
                    return input / 2.83495231;
                }
                else if (conversionoutputcb.Text == "Pounds")
                {
                    return input / 45.359237;
                }
                else if (conversionoutputcb.Text == "Stone")
                {
                    return input / 635.029318;
                }
            }
            if (conversioninputcb.Text == "Hectograms")
            {
                if (conversionoutputcb.Text == "Milligrams")
                {
                    return input * 100000;
                }
                else if (conversionoutputcb.Text == "Centigrams")
                {
                    return input * 10000;
                }
                else if (conversionoutputcb.Text == "Decigrams")
                {
                    return input * 1000;
                }
                else if (conversionoutputcb.Text == "Grams")
                {
                    return input * 100;
                }
                else if (conversionoutputcb.Text == "Decagrams")
                {
                    return input * 10;
                }
                else if (conversionoutputcb.Text == "Kilograms")
                {
                    return input / 10;
                }
                else if (conversionoutputcb.Text == "Metric Tonnes")
                {
                    return input / 10000;
                }
                else if (conversionoutputcb.Text == "Ounces")
                {
                    return input / 0.2834952311;
                }
                else if (conversionoutputcb.Text == "Pounds")
                {
                    return input / 4.5359237;
                }
                else if (conversionoutputcb.Text == "Stone")
                {
                    return input / 63.5029318;
                }
            }
            if (conversioninputcb.Text == "Kilograms")
            {
                if (conversionoutputcb.Text == "Milligrams")
                {
                    return input * 1000000;
                }
                else if (conversionoutputcb.Text == "Centigrams")
                {
                    return input * 100000;
                }
                else if (conversionoutputcb.Text == "Decigrams")
                {
                    return input * 10000;
                }
                else if (conversionoutputcb.Text == "Grams")
                {
                    return input * 1000;
                }
                else if (conversionoutputcb.Text == "Decagrams")
                {
                    return input * 100;
                }
                else if (conversionoutputcb.Text == "Hectograms")
                {
                    return input * 10;
                }
                else if (conversionoutputcb.Text == "Metric Tonnes")
                {
                    return input / 1000;
                }
                else if (conversionoutputcb.Text == "Ounces")
                {
                    return input / 0.0283495231;
                }
                else if (conversionoutputcb.Text == "Pounds")
                {
                    return input / 0.45359237;
                }
                else if (conversionoutputcb.Text == "Stone")
                {
                    return input / 6.35029318;
                }
            }
            if (conversioninputcb.Text == "Metric Tonnes")
            {
                if (conversionoutputcb.Text == "Milligrams")
                {
                    return input * 1000000000;
                }
                else if (conversionoutputcb.Text == "Centigrams")
                {
                    return input * 100000000;
                }
                else if (conversionoutputcb.Text == "Decigrams")
                {
                    return input * 10000000;
                }
                else if (conversionoutputcb.Text == "Grams")
                {
                    return input * 1000000;
                }
                else if (conversionoutputcb.Text == "Decagrams")
                {
                    return input * 100000;
                }
                else if (conversionoutputcb.Text == "Hectograms")
                {
                    return input * 10000;
                }
                else if (conversionoutputcb.Text == "Kilograms")
                {
                    return input * 1000;
                }
                else if (conversionoutputcb.Text == "Ounces")
                {
                    return input / 0.0000283495231;
                }
                else if (conversionoutputcb.Text == "Pounds")
                {
                    return input / 0.00045359237;
                }
                else if (conversionoutputcb.Text == "Stone")
                {
                    return input / 0.00635029318;
                }
            }
            if (conversioninputcb.Text == "Ounces")
            {
                if (conversionoutputcb.Text == "Milligrams")
                {
                    return input * 28349.5231;
                }
                else if (conversionoutputcb.Text == "Centigrams")
                {
                    return input * 2834.95231;
                }
                else if (conversionoutputcb.Text == "Decigrams")
                {
                    return input * 283.495231;
                }
                else if (conversionoutputcb.Text == "Grams")
                {
                    return input * 28.3495231;
                }
                else if (conversionoutputcb.Text == "Decagrams")
                {
                    return input * 2.83495231;
                }
                else if (conversionoutputcb.Text == "Hectograms")
                {
                    return input * 0.283495231;
                }
                else if (conversionoutputcb.Text == "Kilograms")
                {
                    return input * 0.0283495231;
                }
                else if (conversionoutputcb.Text == "Metric Tonnes")
                {
                    return input * 0.0000283495231;
                }
                else if (conversionoutputcb.Text == "Pounds")
                {
                    return input / 16;
                }
                else if (conversionoutputcb.Text == "Stone")
                {
                    return input / 224;
                }
            }
            if (conversioninputcb.Text == "Pounds")
            {
                if (conversionoutputcb.Text == "Milligrams")
                {
                    return input * 453592.37;
                }
                else if (conversionoutputcb.Text == "Centigrams")
                {
                    return input * 45359.237;
                }
                else if (conversionoutputcb.Text == "Decigrams")
                {
                    return input * 4535.9237;
                }
                else if (conversionoutputcb.Text == "Grams")
                {
                    return input * 453.59237;
                }
                else if (conversionoutputcb.Text == "Decagrams")
                {
                    return input * 45.359237;
                }
                else if (conversionoutputcb.Text == "Hectograms")
                {
                    return input * 4.5359237;
                }
                else if (conversionoutputcb.Text == "Kilograms")
                {
                    return input * 0.45359237;
                }
                else if (conversionoutputcb.Text == "Metric Tonnes")
                {
                    return input * 0.00045359237;
                }
                else if (conversionoutputcb.Text == "Ounces")
                {
                    return input * 16;
                }
                else if (conversionoutputcb.Text == "Stone")
                {
                    return input / 14;
                }
            }
            if (conversioninputcb.Text == "Stone")
            {
                if (conversionoutputcb.Text == "Milligrams")
                {
                    return input * 6350293.18;
                }
                else if (conversionoutputcb.Text == "Centigrams")
                {
                    return input * 635029.318;
                }
                else if (conversionoutputcb.Text == "Decigrams")
                {
                    return input * 63502.9318;
                }
                else if (conversionoutputcb.Text == "Grams")
                {
                    return input * 6350.29318;
                }
                else if (conversionoutputcb.Text == "Decagrams")
                {
                    return input * 635.029318;
                }
                else if (conversionoutputcb.Text == "Hectograms")
                {
                    return input * 63.5029318;
                }
                else if (conversionoutputcb.Text == "Kilograms")
                {
                    return input * 6.35029318;
                }
                else if (conversionoutputcb.Text == "Metric Tonnes")
                {
                    return input * 0.00635029318;
                }
                else if (conversionoutputcb.Text == "Ounces")
                {
                    return input * 224;
                }
                else if (conversionoutputcb.Text == "Pounds")
                {
                    return input * 14;
                }
            }
            return -1;
        }
        //END: Code of Methods for the Conversions ComboBox Options (25/09/17) - A

        public double callAllMethods(double input) //callsALLconversionmethods
        {
            if (conversioncb.Text == "Angle") return angleMethods(input);
            else if (conversioncb.Text == "Area") return areaMethods(input);
            else if (conversioncb.Text == "Data Storage") return dataStorageMethods(input);
            else if (conversioncb.Text == "Frequency") return dataStorageMethods(input);
            else if (conversioncb.Text == "Length") return lengthMethods(input);
            else if (conversioncb.Text == "Pressure") return pressureMethods(input);
            else if (conversioncb.Text == "Volume") return volumeMethods(input);
            else if (conversioncb.Text == "Weight/Mass") return weightmassMethods(input);
            else if (conversioncb.Text == "Temperature") return temperatureMethods(input);
            return -1;
        }
        //END: Code of Methods for the Conversions ComboBox Options - A

        private void Perimeter_ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (Perimeter_ComboBox.SelectedIndex == 0)//if the selection is square
            {

                Window1 squarePerimeterWindow = new Window1();
                squarePerimeterWindow.Show();
            }
            if (Perimeter_ComboBox.SelectedIndex == 1)//if the selection is rectangle
            {
                RectanglePerimeterWindow r1 = new RectanglePerimeterWindow();
                r1.Show();
            }
        }


        private void Circumference_ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (Circumference_ComboBox.SelectedIndex == 0)
            {
                CircleCircumferenceWindow c1 = new CircleCircumferenceWindow();
                c1.Show();
            }
        }

        private void Area_ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (Area_ComboBox.SelectedIndex == 0)
            {
                CircleAreaWindow a1 = new CircleAreaWindow();
                a1.Show();
            }
            if (Area_ComboBox.SelectedIndex == 1)
            {
                RectangleAreaWindow r1 = new RectangleAreaWindow();
                r1.Show();
            }
            if (Area_ComboBox.SelectedIndex == 2)
            {
                SquareAreaWindow s1 = new SquareAreaWindow();
                s1.Show();
            }
            if (Area_ComboBox.SelectedIndex == 3)
            {
                TrapeziumAreaWindow t1 = new TrapeziumAreaWindow();
                t1.Show();
            }
            if (Area_ComboBox.SelectedIndex == 4)
            {
                TriangleAreaWindow t1 = new TriangleAreaWindow();
                t1.Show();
            }
        }

        private void Volume_ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (Volume_ComboBox.SelectedIndex == 0)
            {
                CylinderVolumeWindow c1 = new CylinderVolumeWindow();
                c1.Show();
            }
            if (Volume_ComboBox.SelectedIndex == 1)
            {
                ConeVolumeWindow c1 = new ConeVolumeWindow();
                c1.Show();
            }
            if (Volume_ComboBox.SelectedIndex == 2)
            {
                SphereVolumeWindow s1 = new SphereVolumeWindow();
                s1.Show();

            }
        }


        private void button1_Click(object sender, RoutedEventArgs e)
        {


        }

        private void Pythagoras_button_Click(object sender, RoutedEventArgs e)
        {
            PythagorasWindow p1 = new PythagorasWindow();
            p1.Show();

        }

        private void Quadratic_button_Click(object sender, RoutedEventArgs e)
        {
            QuadraticEquationWindow q1 = new QuadraticEquationWindow();
            q1.Show();
        }

        private void convertbtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                double conversionresult = callAllMethods(Convert.ToDouble(conversioninputtb.Text));
                conversionoutputtb.Text = Convert.ToString(conversionresult);
        }

            catch (FormatException)
            {
                MessageBox.Show("Please enter a numerical value.");
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            comboBoxSelection(); //Put this code in button to test if comboBox options work - A
        }

        private void KE_button_Click(object sender, RoutedEventArgs e)
        {
            Kinetic_Energy k1 = new Kinetic_Energy();
            k1.Show();
        }

        private void button_Click_1(object sender, RoutedEventArgs e)
        {
            Potential_Energy p1 = new Potential_Energy();
            p1.Show();
        }

        private void button1_Click_1(object sender, RoutedEventArgs e)
        {
            Gravitational_Force g1 = new Gravitational_Force();
            g1.Show();
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            Centripetal_Force c1 = new Centripetal_Force();
            c1.Show();
        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {
            Heat_Energy h1 = new Heat_Energy();
            h1.Show();
        }

        private void button4_Click(object sender, RoutedEventArgs e)
        {
            Translational_Motion_1 t1 = new Translational_Motion_1();
            t1.Show();
        }



        private void button6_Click(object sender, RoutedEventArgs e)
        {
            Translational_Motion3 t3 = new Translational_Motion3();
            t3.Show();
        }

        private void button5_Click_1(object sender, RoutedEventArgs e)
        {
            Translational_Motion2 t2 = new Translational_Motion2();
            t2.Show();
        }
    }
}
