﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Calculator_Project
{
    /// <summary>
    /// Interaction logic for Translational_Motion_1.xaml
    /// </summary>
    public partial class Translational_Motion_1 : Window
    {
        public Translational_Motion_1()
        {
            InitializeComponent();
        }
        PhysClass p1 = new PhysClass();
        private void button_Click(object sender, RoutedEventArgs e)
        {
            double velocity = Convert.ToDouble(vI.Text);
            double a = Convert.ToDouble(a_input.Text);
            double t = Convert.ToDouble(t_input.Text);
            velocity1.Text = "" + p1.kinetic1(velocity, a, t);
        }
    }
}
