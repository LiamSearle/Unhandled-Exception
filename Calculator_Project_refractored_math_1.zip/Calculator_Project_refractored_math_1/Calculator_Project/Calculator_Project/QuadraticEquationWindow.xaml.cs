﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Calculator_Project
{
    /// <summary>
    /// Interaction logic for QuadraticEquationWindow.xaml
    /// </summary>
    public partial class QuadraticEquationWindow : Window
    {
        public QuadraticEquationWindow()
        {
            InitializeComponent();
            label1.Content = "The general formula is ax\xb2+bx+c, this equation finds factors of the equation";
            label2.Content = "a";
            label3.Content = "b";
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {

            // there is a problem here 
            double a = Convert.ToDouble(x2_box.Text);
            double b = Convert.ToDouble(x_box.Text);
            double c = Convert.ToDouble(c_box.Text);

            
            double x1 = ((-b + Math.Sqrt((Math.Pow(b, 2) + ((-4) * a * c))))/(2*a));
            double x2 = ((-b - Math.Sqrt((Math.Pow(b, 2) + ((-4) * a * c))))/(2*a));
            a_box.Text = "" + Math.Round(x1,2);
            b_box.Text = "" + Math.Round(x2, 2);
        }
    }
}
